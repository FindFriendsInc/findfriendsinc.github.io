const functions = require("firebase-functions");
const admin = require("firebase-admin");
// import { doc, setDoc } from "firebase/firestore"; 
const firestore = admin.firestore();
firestore.settings({ ignoreUndefinedProperties: true });
if (!admin.apps.length) {
    admin.initializeApp();
}

exports.addProfile = functions.https.onCall( async (data, context) => {
    const snap = await firestore.collection("users").where("email", "==", data.email).get();
    let batch = firestore.batch();
    snap.forEach(doc => {
        console.log('test,: ', doc.id)
        const ref = admin.firestore()
        .collection('users')  //You need to identify the collection
        .doc(doc.id);
        batch.update(ref, {
            displayName: data.displayName,
            birthDate: data.birthDate,
            gender: data.gender,
            hobbies: data.hobbies,
            voiceRecording: data.voiceRecording,
            profilePicture: data.profilePicture,
            isProfileSetup: true,
        });
    });
    batch.commit();
    return {stat: "success"}
});

exports.getProfile = functions.https.onCall( async (data, context) => {
    const snapshot = await firestore.collection("users").where("email", "==", data.email).get();
    let obj = {};
    snapshot.docs.map((doc) => { //exists only one user of a given email in the database, will have only one iteration
        obj.email = doc.data().email;
        obj.displayName = doc.data().displayName;
        obj.birthDate = doc.data().birthDate;
        obj.gender = doc.data().gender;
        obj.hobbies = doc.data().hobbies;
        obj.voiceRecording = doc.data().voiceRecording;
        obj.profilePicture = doc.data().profilePicture;
        obj.isProfileSetup = doc.data().isProfileSetup;
    });
    return obj;
});

exports.getProfileHasBeenSetup = functions.https.onCall( async (data, context) => {
    const snapshot = await firestore.collection("users").where("email", "==", data.email).get();
    let obj = {};
    snapshot.docs.map((doc) => { //exists only one user of a given email in the database, will have only one iteration
        obj.isProfileSetup = doc.data().isProfileSetup;
    });
    return obj;
});