const functions = require("firebase-functions");
const admin = require("firebase-admin");
const firestore = admin.firestore();
if (!admin.apps.length) {
    admin.initializeApp();
}


exports.getLeaderboard = functions.https.onCall( async (data, context) => {
    const snapshot = await firestore.collection("users").get();
    allUserList = [];
    snapshot.docs.map( (doc) => {
        let obj = {};
        obj.profilePicture = doc.data().profilePicture;
        obj.displayName = doc.data().displayName;
        obj.email = doc.data().email;
        obj.cardLose = doc.data().cardLose;
        obj.cardWin = doc.data().cardWin;
        obj.rpsWin = doc.data().rpsWin;
        obj.rpsLose = doc.data().rpsLose;
        obj.cameraTotalGamesPlayed = doc.data().cameraTotalGamesPlayed;
        obj.metric = obj.cardWin + obj.rpsWin - obj.cardLose - obj.rpsLose;
        allUserList.push(obj);
    });
    allUserList = allUserList.sort((a, b) => { return parseInt(b.metric) - parseInt(a.metric) }).slice(0, 20);
    return allUserList;
});