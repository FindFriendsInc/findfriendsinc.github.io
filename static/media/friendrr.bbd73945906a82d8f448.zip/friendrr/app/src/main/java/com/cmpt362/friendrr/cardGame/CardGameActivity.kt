package com.cmpt362.friendrr.cardGame

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.MainActivity
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import kotlin.collections.ArrayList


// Sound from zapsplat.com

class CardGameActivity: AppCompatActivity() {

    //firebase emulators:start --import=exported-dev-data --export-on-exit=exported-dev-data
    //netstat -ano | findstr :<PORT>
    //taskkill /PID <PID> /F
    private lateinit var button1: ImageButton
    private lateinit var button2: ImageButton
    private lateinit var button3: ImageButton
    private lateinit var button4: ImageButton
    private lateinit var button5: ImageButton
    private lateinit var button6: ImageButton
    private lateinit var button7: ImageButton
    private lateinit var button8: ImageButton
    private lateinit var button9: ImageButton
    private lateinit var button10: ImageButton
    private lateinit var button11: ImageButton
    private lateinit var button12: ImageButton

    private lateinit var buttons: ArrayList<ImageButton>
    private lateinit var memoryCards: List<MemoryCard>
    private lateinit var memCard1: MemoryCard
    private lateinit var memCard2: MemoryCard

    private lateinit var gameScoreText: TextView
    private lateinit var playerTurnText: TextView

    private lateinit var currentPlayer: Player
    private lateinit var otherPlayer: Player

    private lateinit var deleteButton: Button

    private var counter = 0
    private var playerTurn = 1

    private lateinit var cardGameState: CardGameState

    private lateinit var oppEmail: String
    private lateinit var oppName: String
    private var currName = "test"


    private var images: MutableList<Int> = mutableListOf(
        R.drawable.ic_chat_svgrepo_com,
        R.drawable.ic_handshake_svgrepo_com,
        R.drawable.ic_launcher_background,
        R.drawable.ic_launcher_foreground,
        R.drawable.ic_profile_svgrepo_com,
        R.drawable.blackreaperken
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_card)

        playerTurnText = findViewById(R.id.cardGameTurnText)
        gameScoreText = findViewById(R.id.cardGameScoreText)
        

        initializeButtons()
        oppEmail = intent.getStringExtra(Constant.KEY_RECEIVER_ID).toString()
        oppName = intent.getStringExtra(Constant.OPP_DISPLAY_NAME).toString()

        getGameState(oppEmail)

        deleteButton = findViewById(R.id.endGameButton)
    }

    private fun setup() {

        try {
            var database = FirebaseFirestore.getInstance()
            var currentUserEmail = ProfileHelper.getCurrentEmail(this)
            // Get display name of current user
            // CURRENTLY CRASHING
            database.collection("users")
                .whereEqualTo("email", currentUserEmail)
                .limit(1)
                .get()
                .addOnSuccessListener { result ->
                    if (result.documents.size > 0) {
                        println("debug: onSuccess ${result.documents[0].data!!["displayName"]}")
                        currName = result.documents[0].data!!["displayName"] as String

                        print("debug: name is now $currName")

                        currentPlayer = Player(currName, ProfileHelper.getCurrentEmail(this))
                        otherPlayer = Player(oppName, oppEmail)

                        currentPlayer.theirTurn = true

                        images.addAll(images)
                        images.shuffle()

                        memoryCards = buttons.indices.map { index ->
                            MemoryCard(images[index], index, "empty")
                        }

                        cardGameState = CardGameState()
                        cardGameState.cards = memoryCards
                        cardGameState.turn = playerTurn
                        cardGameState.cards = memoryCards
                        cardGameState.currPlayer = currentPlayer
                        cardGameState.otherPlayer = otherPlayer

                        gameScoreText.text = "${currentPlayer.name}: ${currentPlayer.score} " +
                                "${otherPlayer.name}: ${otherPlayer.score}"

                        checkTurn(currentPlayer, otherPlayer)
                    }
                }
                .addOnFailureListener{
                    println("debug: onFailure $it")
                }
        } catch (e: IllegalStateException) {
            println("debug: caught $e")
        }
    }

    private fun initializeButtons() {
        button1 = findViewById(R.id.cardGameButton1)
        button2 = findViewById(R.id.cardGameButton2)
        button3 = findViewById(R.id.cardGameButton3)
        button4 = findViewById(R.id.cardGameButton4)
        button5 = findViewById(R.id.cardGameButton5)
        button6 = findViewById(R.id.cardGameButton6)
        button7 = findViewById(R.id.cardGameButton7)
        button8 = findViewById(R.id.cardGameButton8)
        button9 = findViewById(R.id.cardGameButton9)
        button10 = findViewById(R.id.cardGameButton10)
        button11 = findViewById(R.id.cardGameButton11)
        button12 = findViewById(R.id.cardGameButton12)

        buttons = ArrayList()
        buttons.add(button1)
        buttons.add(button2)
        buttons.add(button3)
        buttons.add(button4)
        buttons.add(button5)
        buttons.add(button6)
        buttons.add(button7)
        buttons.add(button8)
        buttons.add(button9)
        buttons.add(button10)
        buttons.add(button11)
        buttons.add(button12)

        for(i in buttons.indices) {
            buttons[i].setOnClickListener {
                val card = memoryCards[i]

                // If card already flipped, keep it flipped
                if(card.isFaceUp) {
                    Toast.makeText(this, "Card is already flipped!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                // Increase card flipped counter
                counter++

                println("debug: made a move as ${currentPlayer.name}")

                // Check card to see if match
                checkCard(card)
            }
        }
    }

    private fun getGameState(opponentEmail: String) {

        val data = hashMapOf(
            "currUserEmail" to ProfileHelper.getCurrentEmail(this),
            "otherUserEmail" to opponentEmail
        )
        var retObj: String?

        FirebaseFunctions.getInstance()
            .getHttpsCallable("getGameState")
            .call(data)
            .addOnFailureListener {
                println("debug: failed to get state")
            }
            .addOnSuccessListener {
                val retData = it.data
                if(retData != null) {
                    retObj = it.data as? String
                    cardGameState = Gson().fromJson(retObj, CardGameState::class.java)
                    println("debug: success conversion")
                    updateGameUI(cardGameState)
                }
                else {
                    setup()
                    println("debug: initializing the first time")
                }
            }
    }

    private fun updateGameUI(cardGameState: CardGameState?) {

        playerTurn = cardGameState?.turn!!

        // Check for matching player data with proper user
        if(cardGameState.currPlayer!!.email == ProfileHelper.getCurrentEmail(this)) {
            currentPlayer = cardGameState.currPlayer!!
            otherPlayer = cardGameState.otherPlayer!!
        }
        else if(cardGameState.currPlayer!!.email != ProfileHelper.getCurrentEmail(this)) {
            currentPlayer = cardGameState.otherPlayer!!
            otherPlayer = cardGameState.currPlayer!!
        }

        memoryCards = cardGameState.cards

        val cards = cardGameState.cards
        val size = cardGameState.cards.size - 1
        for(i in cards.indices) {
            if(cards[i].isFaceUp) {
                buttons[i].setBackgroundResource(cards[i].image)
            }
            else {
                buttons[i].setBackgroundResource(R.drawable.ic_magnifying_glass_svgrepo_com)
            }
            for(j in 1..size) {
                if(checkMatch(cards[i], cards[j])) {
                    buttons[i].alpha = 0.1f
                    buttons[j].alpha = 0.1f
                }
            }
        }

        images.addAll(images)

        for(i in 0..size) {
            images[i] = cards[i].image
        }

        gameScoreText.text = "${currentPlayer.name}: ${currentPlayer.score} " +
                "${otherPlayer.name}: ${otherPlayer.score}"
        checkTurn(currentPlayer, otherPlayer)
        checkCardGameState()
    }

    private fun checkMatch(card1: MemoryCard, card2: MemoryCard) : Boolean {
        // Both cards are face up and belong to same player
        if(card1.isFaceUp && card2.isFaceUp && card1.claimed == card2.claimed)
            return true

        return false
    }

    private fun checkCard(card: MemoryCard) {

        if(counter == 1) {
            card.isFaceUp = !card.isFaceUp
            memCard1 = card
        }
        else if(counter == 2) {
            card.isFaceUp = !card.isFaceUp
            memCard2 = card

            // There is a match between the two cards
            if(memCard1.image == memCard2.image) {
                if(currentPlayer.theirTurn && !otherPlayer.theirTurn) {
                    currentPlayer.score++
                }
                else if(!currentPlayer.theirTurn && otherPlayer.theirTurn) {
                    otherPlayer.score++
                }

                // Sound from zapsplat.com
                val mediaPlayer = MediaPlayer.create(this, R.raw.zapsplat_multimedia_correct_ping_tone_001_68778)
                mediaPlayer.start()
                Toast.makeText(this, "Match found!", Toast.LENGTH_SHORT).show()
                counter = 0
            }
            else {
                val runnable = Runnable{
                    memoryCards[memCard1.position].isFaceUp = false
                    memoryCards[memCard2.position].isFaceUp = false
                    buttons[memCard1.position].setBackgroundResource(R.drawable.ic_magnifying_glass_svgrepo_com)
                    buttons[memCard2.position].setBackgroundResource(R.drawable.ic_magnifying_glass_svgrepo_com)
                    memCard1 = card
                    counter = 0

                }
                Handler(Looper.getMainLooper()).postDelayed(runnable, 1000)
            }

            val run = {
                updateGameState() // Store game state into db
                finish()
            }
            Handler(Looper.getMainLooper()).postDelayed(run, 2000)
        }
        updateMyUI(memoryCards)
    }

    private fun updateMyUI(cards: List<MemoryCard>) {
        for(i in cards.indices) {
            if(cards[i].isFaceUp) {
                buttons[i].setBackgroundResource(images[i])
            }
            else {
                buttons[i].setBackgroundResource(R.drawable.ic_magnifying_glass_svgrepo_com)
            }
        }

        gameScoreText.text = "${currentPlayer.name}: ${currentPlayer.score} " +
                "${otherPlayer.name}: ${otherPlayer.score}"
    }
    private fun switchTurn() {
        // Current players turn currently
        if(currentPlayer.theirTurn && !otherPlayer.theirTurn) {
            currentPlayer.theirTurn = !currentPlayer.theirTurn
            otherPlayer.theirTurn = !otherPlayer.theirTurn
        }
        // Other players turn currently
        else if(!currentPlayer.theirTurn && otherPlayer.theirTurn) {
            currentPlayer.theirTurn = !currentPlayer.theirTurn
            otherPlayer.theirTurn = !otherPlayer.theirTurn
        }
    }

    private fun checkCardGameState() {
        // Check if all cards are flipped, indicating game is over
        if(allFlippedCards(memoryCards)) {

            val build = AlertDialog.Builder(this)
            build.setTitle("Game over!")

            if(currentPlayer.score > otherPlayer.score) {
                build.setMessage("${currentPlayer.name} wins!")
            }
            else if(otherPlayer.score > currentPlayer.score) {
                build.setMessage("${otherPlayer.name} wins!")
            }
            else {
                build.setMessage("It's a tie!")
            }

            build.setNegativeButton("End") { _, _ ->
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }

            build.show()
            if(currentPlayer.score > otherPlayer.score) {
                deleteGameState(currentPlayer.email, otherPlayer.email)
            }
            else if(otherPlayer.score > currentPlayer.score){
                deleteGameState(otherPlayer.email, currentPlayer.email)
            }
            else {
                deleteGameState(null, null)
            }
        }
    }

    private fun checkTurn(curr: Player, opp: Player) {

        if(curr.theirTurn) {
            editButtonEnable(curr)
            playerTurnText.text = "${curr.name}'s turn"
        }
        else if(opp.theirTurn) {
            editButtonEnable(curr)
            playerTurnText.text = "${opp.name}'s turn"
        }
    }

    private fun editButtonEnable(player: Player) {

        // Our turn, so enable buttons
        if(player.theirTurn) {
            for(i in buttons.indices) {
                buttons[i].isEnabled = true
                buttons[i].isClickable = true
            }
        }
        // Other player turn, make board not clickable
        else if(!player.theirTurn) {
            for(i in buttons.indices) {
                buttons[i].isEnabled = false
                buttons[i].isClickable = false
            }
        }

    }

    private fun allFlippedCards(cards: List<MemoryCard>): Boolean {

        for(i in cards.indices) {
            if(!cards[i].isFaceUp) {
                return false
            }
        }

        return true
    }

    private fun deleteGameState(winEmail: String?, loseEmail: String?): Any {
        if(winEmail == null || loseEmail == null) {
            cardGameState.gameName = "nothing"
        }

        val data = hashMapOf(
            "currUserEmail" to ProfileHelper.getCurrentEmail(this),
            "otherUserEmail" to otherPlayer.email,
            "gameType" to cardGameState.gameName,
            "winEmail" to winEmail,
            "loseEmail" to loseEmail
        )
        return try {
            FirebaseFunctions.getInstance()
                .getHttpsCallable("deleteGameState")
                .call(data)
                .addOnFailureListener {
                    println("debug: failed to delete state")
                }
                .addOnSuccessListener {
                    println("debug: delete state success")


                }
        } catch(e: Exception) {
            println("debug: $e")
        }
    }

    private fun updateGameState() {

        switchTurn()
        cardGameState.cards = memoryCards
        cardGameState.currPlayer = currentPlayer
        cardGameState.otherPlayer = otherPlayer
        cardGameState.turn = playerTurn

        val gson = GsonBuilder().create()
        val gameStateObj = cardGameState
        val objJson = gson.toJson(gameStateObj)
        val data = hashMapOf(
            "gameState" to objJson,
            "currUserEmail" to ProfileHelper.getCurrentEmail(this),
            "otherUserEmail" to otherPlayer.email
        )

        FirebaseFunctions.getInstance()
            .getHttpsCallable("updateGameState")
            .call(data)
            .addOnSuccessListener {
                println("debug: successfully updated game state")
            }
            .addOnFailureListener {
                println("debug: failed updating game state")
            }

    }

    fun onEndGameClick(v: View) {
        println("debug: clicked end game")
        val build = AlertDialog.Builder(this)
        build.setTitle("End Game")
        build.setMessage("Do you want to end this game activity with $oppName?")
        build.setPositiveButton("Yes") { _, _ ->
            deleteGameState(null,null)
            finish()
            println("debug: deleted game state")
        }
        build.setNegativeButton("No") { _, _ ->
            Toast.makeText(this, "Continue on with the game", Toast.LENGTH_SHORT).show()
        }

        build.show()
    }
}