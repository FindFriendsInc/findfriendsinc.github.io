package com.cmpt362.friendrr.photoRoulette

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R

class WaitTurnActivity: AppCompatActivity(), View.OnClickListener  {
    private lateinit var exitButton: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wait_turn)
        exitButton = findViewById(R.id.exit)
        exitButton.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.exit -> {
                finish()
            }
        }
    }
}