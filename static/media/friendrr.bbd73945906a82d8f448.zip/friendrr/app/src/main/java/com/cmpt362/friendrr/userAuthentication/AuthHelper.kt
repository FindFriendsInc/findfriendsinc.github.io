package com.cmpt362.friendrr.userAuthentication

import android.util.Patterns
import java.util.regex.Pattern

object AuthHelper {
    fun validateEmail (email: String): Boolean {
        val pattern: Pattern = Patterns.EMAIL_ADDRESS
        println("debug: " + pattern.matcher(email).matches() + " " + email)
        return pattern.matcher(email).matches()
    }

    fun validatePassword (pass: String): Boolean {
        if (pass.length < 8) {
            return false
        }
        return true
    }

    fun emailFormatter (email: String): String {
        return email.trim { it <= ' '}
    }

    fun passwordFormatter (password: String): String {
        return password.trim {it <= ' '}
    }
}