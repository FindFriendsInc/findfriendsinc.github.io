const functions = require("firebase-functions");
const auth = require("./AuthFunctions");
const profile = require("./profileFunctions");
const friendFunction = require("./friendFunctions");
const gameFunctions = require("./gameFunctions");
const leaderboardFunctions = require("./leaderboardFunctions");
// The Firebase Admin SDK to access Cloud Firestore

const searchFunction = require("./search");
const updateDateFunction = require("./updateLoginDateFunctions");

exports.addUserToFirestore = auth.addUserToFirestore;
exports.searchFunction = searchFunction.search;


exports.addProfile = profile.addProfile;
exports.getProfile = profile.getProfile;
exports.getProfileHasBeenSetup = profile.getProfileHasBeenSetup;

exports.updateUserLoginDate = updateDateFunction.updateLoginDate;


exports.rightSwipe = friendFunction.rightSwipe;
exports.friendRequest = friendFunction.friendRequest;
exports.removeFriend = friendFunction.removeFriend;
exports.getCandidateAndFriendList = friendFunction.getCandidateAndFriendList;
exports.removeMatchedCandidate = friendFunction.removeMatchedCandidate;
exports.getUserInfoForChat = friendFunction.getUserInfoForChat;
exports.updateGameState = gameFunctions.updateGameState;
exports.getGameState = gameFunctions.getGameState;
exports.deleteGameState = gameFunctions.deleteGameState;

exports.getLeaderboard = leaderboardFunctions.getLeaderboard;
