package com.cmpt362.friendrr.friendMatch

import android.app.Activity
import android.media.MediaPlayer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.cmpt362.friendrr.query.FriendQuery
import com.google.firebase.functions.FirebaseFunctions
import com.yalantis.library.KolodaListener
import android.util.Base64
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.cmpt362.friendrr.GlobalViewModel

import com.yalantis.library.Koloda
import java.io.File
import kotlin.collections.ArrayList

class SwipeFragment: Fragment() {
    private lateinit var adapter: SwipeAdapter
    private lateinit var list: List<Int>
    private lateinit var users:ArrayList<Map<String, *>>
    private lateinit var koloda: Koloda
    private lateinit var replayBtn:Button
    private lateinit var listeningText:TextView
    private lateinit var replayViewModel: ReplayViewModel
    private var mediaPlayer: MediaPlayer? = null
    private var email  = ""
    private var userPosition = 0
    private var replay = false
    private var currLoadingState = false
    override fun onCreateView(
        inflater: LayoutInflater,
        viewGroup: ViewGroup?,
        bundle: Bundle?
    ): View? {
        val retView = inflater.inflate(R.layout.fragment_friend_swipe, viewGroup, false)
        koloda = retView.findViewById(R.id.koloda)
        list = ArrayList<Int>()
        users = ArrayList<Map<String,*>>()
        listeningText = retView.findViewById(R.id.listenText)
        replayBtn = retView.findViewById(R.id.replayButton)
        replayViewModel = ViewModelProvider(requireActivity()).get(ReplayViewModel::class.java)
        email = ProfileHelper.getCurrentEmail(context as Activity)
        val data = hashMapOf(
            "email" to email
        )
        var globalViewModel = ViewModelProvider(requireActivity()).get(GlobalViewModel::class.java)
        globalViewModel.setLoadingStatus(true)
        FirebaseFunctions.getInstance()
            .getHttpsCallable("searchFunction")
            .call(data)
            .addOnSuccessListener {
                users = it.data as ArrayList<Map<String, *>>
                adapter = SwipeAdapter(requireActivity(), list, users)
                koloda.adapter = adapter
                globalViewModel.setLoadingStatus(false)
            }
            .addOnFailureListener {
                println("unsuccessful $it")
                globalViewModel.setLoadingStatus(false)
            }
        replayViewModel.replay.observe(requireActivity()){
            if(it){
                if(users.isEmpty() || userPosition == users.size){
                    val text = "No more users!"
                    listeningText.text = text
                    replayBtn.isEnabled = false
                }else{
                    if(users.size > 0){
                        val text = "Press replay to listen again"
                        listeningText.text = text
                        replayBtn.isEnabled = true
                    } else{
                        val text = "No more users!"
                        listeningText.text = text
                        replayBtn.isEnabled = false
                    }
                }
            }else{
                println("JO ${users.isEmpty()}")
                if(users.isEmpty() || userPosition == users.size){
                    releaseMedia()
                    val text = "No more users!"
                    listeningText.text = text
                    replayBtn.isEnabled = false
                }else{
                    val text = "Now listening to the user's recording"
                    listeningText.text = text
                    replayBtn.isEnabled = false
                }
            }
        }


        replayBtn.setOnClickListener{
            if(userPosition >= 0 && userPosition < users.size && !users.isEmpty() && replayViewModel.replay.value == true){
                replayViewModel.replay.value = false
                val encodedRecording = users.get(userPosition).get("voiceRecording").toString()
                if(encodedRecording != ""){
                    val byteArrayRecording = Base64.decode(encodedRecording, 0)
                    mediaPlayer = ProfileHelper.playMp3(requireActivity(), byteArrayRecording, File(requireActivity().getExternalFilesDir(null), "friendrr_audio_recording.mp3"))
                    mediaPlayer!!.setOnCompletionListener {
                        replayViewModel.replay.value = true
                    }
                }else{
                    replayViewModel.replay.value = true
                }

            }
        }

        koloda.kolodaListener = object : KolodaListener {
            override fun onNewTopCard(position: Int) {
                releaseMedia()
                replayViewModel.replay.value = false
                if (!users.isEmpty()) {
                    try {
                        val encodedRecording =
                            users.get(position + 1).get("voiceRecording").toString()
                        println(encodedRecording)
                        if (encodedRecording != "") {
                            val byteArrayRecording = Base64.decode(encodedRecording, 0)
                            mediaPlayer = ProfileHelper.playMp3(
                                requireActivity(),
                                byteArrayRecording,
                                File(
                                    requireActivity().getExternalFilesDir(null),
                                    "friendrr_audio_recording.mp3"
                                )
                            )
                            mediaPlayer!!.setOnCompletionListener {
                                replay = true
                                replayViewModel.replay.value = true
                            }
                        }
                    }catch (e:Exception){
                        replayViewModel.replay.value = true
                    }

                }

            }

            override fun onCardSwipedRight(position: Int) {
                //todo realize your logic
                println("onCardSwipedRight position ${koloda.adapter!!.getItem(position + 1)}")
                val userMap = koloda.adapter!!.getItem(position + 1) as Map<String, *>
                FriendQuery.rightSwipe(
                    requireActivity(), ProfileHelper.getCurrentEmail(requireActivity()),
                    userMap["email"].toString()
                )
                userPosition = userPosition + 1
                replayViewModel.replay.value = false

            }

            override fun onCardSwipedLeft(position: Int) {
                userPosition = userPosition + 1
                replayViewModel.replay.value = false
            }

            override fun onEmptyDeck() {
                Toast.makeText(
                    requireActivity(),
                    "You have swiped through all the recommended users!",
                    Toast.LENGTH_LONG
                ).show()
            }

        }
        return retView
    }
    private fun releaseMedia(){
        if (mediaPlayer != null) {
            mediaPlayer!!.stop();
            mediaPlayer!!.reset()
            mediaPlayer!!.release();
            mediaPlayer = null;
        }
    }
    override fun onPause() {
        releaseMedia()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseMedia()
    }

}


