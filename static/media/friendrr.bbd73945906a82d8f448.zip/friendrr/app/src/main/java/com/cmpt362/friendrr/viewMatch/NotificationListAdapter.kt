package com.cmpt362.friendrr.viewMatch

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.cmpt362.friendrr.R

class NotificationListAdapter(private val context: Context, private var entryList: List<MatchUser>):
    BaseAdapter() {
    override fun getCount(): Int {
        return entryList.size
    }

    override fun getItem(position: Int): Any {
        return entryList[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = View.inflate(context, R.layout.fragment_view_match_list_layout,null)
        val textViewDisplayName = view.findViewById(R.id.display_name_row) as TextView
        val textViewDescription = view.findViewById(R.id.description_row) as TextView
        val imgView = view.findViewById(R.id.match_profile_img) as ImageView
        val userObj = entryList[position]
        lateinit var description:String

        if(userObj.getRelationType() == "friend") {
            view.findViewById<RelativeLayout>(R.id.viewMatchListItemContainer).setBackgroundColor(
                ContextCompat.getColor(context, R.color.friend_background))
            textViewDisplayName.text = "New Friend!"
            description = "You are now friends with ${userObj.getDisplayName()}"
        }else if(userObj.getRelationType() == "friendCandidate") {
            textViewDisplayName.text = "New Match!"
            description = "You are now matched with ${userObj.getDisplayName()}"
        }

        textViewDescription.text = description
        val imageAsBytes = Base64.decode(userObj.getProfilePicture().toByteArray(), Base64.DEFAULT)
        imgView.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size))
        return view
    }
}