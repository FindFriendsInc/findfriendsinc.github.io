package com.cmpt362.friendrr.photoRoulette

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.GsonBuilder
import org.w3c.dom.Text

class GuessActivity: AppCompatActivity(), View.OnClickListener{
    private lateinit var otherUserEmail: String
    private lateinit var imgView: ImageView
    private lateinit var guessText: TextView
    private lateinit var guessButton: Button
    private lateinit var okButton: Button
    private lateinit var titleText: TextView
    private lateinit var currGameState: GameState
    private lateinit var userGuessInput: EditText
    var hasGuess = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_guess_picture)
        otherUserEmail = intent.getStringExtra(Constant.OTHER_USER_EMAIL_KEY).toString()
        imgView = findViewById(R.id.guess_image)
        guessText = findViewById(R.id.guess_hint)
        guessButton = findViewById(R.id.guess_button)
        okButton = findViewById(R.id.ok_button)
        guessButton.setOnClickListener(this)
        okButton.setOnClickListener(this)
        titleText = findViewById(R.id.title)
        userGuessInput = findViewById(R.id.user_input_guess)
        if(!hasGuess) {
            okButton.visibility = View.GONE
        }

        val data = HashMap<String, Any>()
        data["currUserEmail"] = ProfileHelper.getCurrentEmail(this)
        data["otherUserEmail"] = otherUserEmail
        
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getGameState")
            .call(data)
            .addOnSuccessListener {
                println("getGameState success  ${it.data}")
                val retStr = it.data as String
                val gson = GsonBuilder().create()
                currGameState = gson.fromJson(retStr, GameState::class.java)
                val imageAsBytes = Base64.decode(currGameState.currentPhoto.toByteArray(), Base64.DEFAULT)
                imgView.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size))
                guessText.text = "Hint: ${GameHelper.randomizedString(currGameState.currentGuessWord)}"
            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.guess_button -> {
                if(userGuessInput.text.toString() == ""){
                    Toast.makeText(this, "Don't leave your guess blank!", Toast.LENGTH_LONG).show()
                }else {
                    if(userGuessInput.text.toString() == currGameState.currentGuessWord){
                        titleText.text = "Correct Guess!"
                    }else {
                        titleText.text = "Incorrect Guess"
                    }
                    okButton.visibility = View.VISIBLE
                    if(currGameState.currentRound == 3){
                        okButton.text = "Finish Game"
                    }
                    guessButton.visibility = View.GONE
                }
            }
            R.id.ok_button -> {
                if(currGameState.currentRound == 3){
                    val data = HashMap<String, Any>()
                    data["currUserEmail"] = ProfileHelper.getCurrentEmail(this)
                    data["otherUserEmail"] = otherUserEmail
                    data["gameType"] = "photoGame"
                    data["winEmail"] = ProfileHelper.getCurrentEmail(this)
                    data["loseEmail"] = otherUserEmail
                    okButton.isEnabled = false
                    FirebaseFunctions.getInstance()
                        .getHttpsCallable("deleteGameState")
                        .call(data)
                        .addOnSuccessListener {
                            println("deleteGameState success  ${it.data}")
                            finish()
                        }
                        .addOnFailureListener {
                            println("unsuccessful $it")
                        }
                }else{
                    val intent = Intent(this, PictureActivity::class.java)
                    intent.putExtra( "GAME_TYPE_KEY", GameConstants.EXISTING_GAME)
                    intent.putExtra(Constant.OTHER_USER_EMAIL_KEY, otherUserEmail)
                    intent.putExtra(GameConstants.ROUNDS_KEY, currGameState.currentRound)
                    startActivity(intent)
                }
            }
        }
    }
}