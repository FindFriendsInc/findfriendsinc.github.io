const functions = require("firebase-functions");
// The Firebase Admin SDK to access Cloud Firestore
const admin = require("firebase-admin");
if (!admin.apps.length) {
    admin.initializeApp();
}

// adds basic attribute to the database
exports.addUserToFirestore = functions.auth.user().onCreate((user) => {
    const datetime = new Date();
    const userRef = admin.firestore().collection("users");
    return userRef.doc(user.uid).set({
        email: user.email,
        gameActivity: {},
        lastLoggedInDate: datetime.toISOString().slice(0, 10),
        friendList: [],
        matchedCandidateList: [],
        outgoingRightSwipeList: [],
        incomingRightSwipeList: [],
        isProfileSetup: false,
        outgoingFriendRequestList: [],
        incomingFriendRequestList: [],
        rpsWin: 0,
        rpsLose: 0,
        cardWin: 0,
        cardLose: 0,
        cameraTotalGamesPlayed: 0,
        voiceRecording: "",
    });
});
