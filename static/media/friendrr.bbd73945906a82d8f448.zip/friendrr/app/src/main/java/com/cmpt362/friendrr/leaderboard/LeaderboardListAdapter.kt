package com.cmpt362.friendrr.leaderboard

import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.android.gms.common.internal.ImagesContract

class LeaderboardListAdapter(private val context: Context, private var leaderboardList: ArrayList<Map<String, *>>): BaseAdapter() {
    override fun getCount(): Int {
        return leaderboardList.size
    }

    override fun getItem(position: Int): Any {
        return leaderboardList.get(position)
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, p1: View?, p2: ViewGroup?): View {
        val view: View = View.inflate(context, R.layout.fragment_leaderboard_list_layout, null)
        val image: ImageView = view.findViewById(R.id.leaderboard_img)
        val rank: TextView = view.findViewById(R.id.leaderboard_rank)
        val name:TextView = view.findViewById(R.id.leaderboard_name)
        val rpsGame: TextView = view.findViewById(R.id.leaderboard_rps)
        val cmGame: TextView = view.findViewById(R.id.leaderboard_cm)
        val snapGame: TextView = view.findViewById(R.id.leaderboard_snap)

        val imageAsBytes = Base64.decode(leaderboardList.get(position).get("profilePicture").toString().toByteArray(), Base64.DEFAULT)

        val rankString = (position + 1).toString()
        image.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size))
        rank.text = context.getString(R.string.rank_text, rankString)
        name.text = context.getString(R.string.name_text, leaderboardList.get(position).get("displayName").toString())
        rpsGame.text = context.getString(R.string.rps_text, leaderboardList.get(position).get("rpsWin").toString(), leaderboardList.get(position).get("rpsLose").toString())
        cmGame.text = context.getString(R.string.cm_text, leaderboardList.get(position).get("cardWin").toString(), leaderboardList.get(position).get("cardLose").toString())
        snapGame.text = context.getString(R.string.snap_text, leaderboardList.get(position).get("cameraTotalGamesPlayed").toString())
        return view
    }
}