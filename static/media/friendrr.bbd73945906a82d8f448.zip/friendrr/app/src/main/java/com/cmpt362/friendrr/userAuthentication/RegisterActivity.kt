package com.cmpt362.friendrr.userAuthentication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileOneActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser


class RegisterActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var registerButton: Button
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        setTitle(R.string.register)

        //REMOVE THIS WHEN DEPLOYING IN PRODUCTION
        //OR MODIFY WHEN TESTING ON PHYSICAL DEVICE
        

        registerButton = findViewById(R.id.register_register_button_id)
        emailInput = findViewById(R.id.register_input_email)
        passwordInput= findViewById(R.id.register_input_password)
        registerButton.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.register_register_button_id -> {
                //handling conditions when users does not enter valid email/password
                if (!AuthHelper.validateEmail(emailInput.text.toString()) ||
                        !AuthHelper.validatePassword(passwordInput.text.toString())) {
                    Toast.makeText(this, "Invalid email or password format", Toast.LENGTH_LONG).show()
                    return
                }
                val email: String = AuthHelper.emailFormatter(emailInput.text.toString())
                val password: String = AuthHelper.passwordFormatter(passwordInput.text.toString())
                //creating new user
                    FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val firebaseUser: FirebaseUser = task.result!!.user!!
                            Toast.makeText(this, "Account successfully created", Toast.LENGTH_LONG).show()

                            // Launch profile setup
                            val intent = Intent(this, LoginActivity::class.java)
                            startActivity(intent)
                        } else {
                            println("LOG: " + task.exception)
                            Toast.makeText(this, "Registration failed", Toast.LENGTH_LONG).show()
                        }
                    }
            }
        }
    }
}