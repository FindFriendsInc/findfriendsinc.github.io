package com.cmpt362.friendrr.chat

import java.util.*

class ChatMessage : Comparable<Any> {
    public lateinit var senderId: String
    public lateinit var receiverId: String
    public lateinit var message: String
    public lateinit var dateTime: String

    public lateinit var dateObject: Date

    override fun compareTo(other: Any): Int {
        val otherMessage = other as (ChatMessage)
        return this.dateObject.compareTo(otherMessage.dateObject)
    }
}