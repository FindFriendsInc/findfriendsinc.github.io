package com.cmpt362.friendrr.friendMatch

import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.ktx.functions
import com.google.firebase.ktx.Firebase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap
import kotlin.Any as Any1

class SwipeAdapter(context: Context, list: List<Int>, users: ArrayList<Map<String, *>>): BaseAdapter() {
    private lateinit var context: Context
    private lateinit var list: List<Int>
    private lateinit var userArray: ArrayList<Map<String, *>>
    private lateinit var inflater: LayoutInflater

    init {
        this.context = context
        this.list = list
        userArray = users
        inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
    }

    override fun getCount(): Int {
        return userArray.size
    }

    override fun getItem(position: Int): Map<String, *>{
        return userArray[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        var retView: View? = convertView
        if(retView == null) {
            retView = inflater.inflate(R.layout.item_koloda, parent,false)
        }

        val textHolder = retView?.findViewById<TextView>(R.id.display_name_id)
        val imageHolder = retView?.findViewById<ImageView>(R.id.swipe_profile_image)

        //set display name
        textHolder?.text = userArray.get(position).get("displayName").toString()

        //set profile picture
        val imageAsBytes = Base64.decode(userArray.get(position).get("profilePicture").toString().toByteArray(), Base64.DEFAULT)
        imageHolder?.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size))


        println(userArray.get(position).toString())

        return retView!!
    }
}

