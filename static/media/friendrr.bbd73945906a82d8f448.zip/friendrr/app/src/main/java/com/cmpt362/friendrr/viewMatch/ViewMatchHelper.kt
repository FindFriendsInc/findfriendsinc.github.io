package com.cmpt362.friendrr.viewMatch

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import com.cmpt362.friendrr.Constant

object ViewMatchHelper {
    fun storeProfilePicToLocalCache(activity: Activity, picByteString: String) {
        val sharedPref: SharedPreferences = activity.getSharedPreferences("ViewMatch",
            Context.MODE_PRIVATE)
        with (sharedPref.edit()) {
            putString(Constant.PROFILE_PIC_KEY, picByteString)
            apply()
        }
    }

    fun getProfilePicFromLocalCache(activity: Activity): String {
        val sharedPref: SharedPreferences = activity.getSharedPreferences("ViewMatch",
            Context.MODE_PRIVATE)
        return sharedPref.getString(Constant.PROFILE_PIC_KEY, "")!!
    }
}