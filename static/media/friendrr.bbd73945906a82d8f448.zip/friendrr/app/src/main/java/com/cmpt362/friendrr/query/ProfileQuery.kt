package com.cmpt362.friendrr.query

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.widget.Toast
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.functions.FirebaseFunctions
import java.lang.Exception

object ProfileQuery {
    fun addProfileToDb(activity: Activity, email: String): Any {
        
        val sharedpref: SharedPreferences = activity.getSharedPreferences("profileSetup",
            Context.MODE_PRIVATE)
        val displayName = sharedpref.getString(Constant.DISPLAY_NAME_KEY, "")!!
        val birthDate = sharedpref.getString(Constant.BIRTHDATE_KEY, "")!!
        val gender = sharedpref.getString(Constant.GENDER_KEY, "")!!
        val hobbiesList = sharedpref.getStringSet(Constant.SELECTED_HOBBIES_LIST, null)!!.toList()
        val profilePicture = sharedpref.getString(Constant.PROFILE_PIC_KEY, "")!!
        val voiceRecording = sharedpref.getString(Constant.BYTE_ARRAY_KEY, "")!!
        println("test yo: $hobbiesList")
        val data = HashMap<String, Any>()
        lateinit var retObj: Any
        data["email"] = email
        data["displayName"] = displayName
        data["birthDate"] = birthDate
        data["gender"] = gender
        data["hobbies"] = hobbiesList
        data["profilePicture"] = profilePicture
        data["voiceRecording"] = voiceRecording
        return try {
            FirebaseFunctions.getInstance()
                .getHttpsCallable("addProfile")
                .call(data)
                .addOnFailureListener {
                    println("gg yo $it")
                }
                .addOnSuccessListener {
                    println("success yo ${it.data}")
//                    ProfileHelper.clearCurrentProfileFromLocalStorage(activity)
                    Toast.makeText(activity, "Profile has been saved!", Toast.LENGTH_LONG).show()
//                    it.data!!
                }
        }catch(e: Exception) {
            println(e)
        }
    }

}