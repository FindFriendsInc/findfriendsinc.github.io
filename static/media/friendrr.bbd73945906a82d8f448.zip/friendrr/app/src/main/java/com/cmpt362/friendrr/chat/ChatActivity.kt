package com.cmpt362.friendrr.chat

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.cardGame.CardGameActivity
import com.cmpt362.friendrr.databinding.ActivityChatBinding
import com.cmpt362.friendrr.games.RockPaperScissorActivity
import com.cmpt362.friendrr.photoRoulette.GameState
import com.cmpt362.friendrr.photoRoulette.IntroPhotoRouletteActivity
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.GsonBuilder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap


class ChatActivity : AppCompatActivity() {
    private lateinit var currentUserEmail: String
    private lateinit var receiverEmail: String
    private lateinit var receiverUser: Map<String, *>
    private lateinit var binding: ActivityChatBinding
    private lateinit var chatMessages: List<ChatMessage>
    private lateinit var chatAdapter: ChatAdapter
    private lateinit var database: FirebaseFirestore
    private var isFriend : Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        currentUserEmail = ProfileHelper.getCurrentEmail(this)
        
        loadReceiverDetails()
        setListeners()

    }

    private fun init() {
        chatMessages = ArrayList<ChatMessage>()
        chatAdapter = ChatAdapter(
            chatMessages,
            getBitmapFromEncodedString(receiverUser["profilePicture"] as String),
            currentUserEmail
        )
        binding.chatRecyclerView.adapter = chatAdapter


        database = FirebaseFirestore.getInstance()

    }

    private fun sendMessage() {
        var message: HashMap<String, Any> = HashMap()
        message[Constant.KEY_SENDER_ID] = currentUserEmail
        message[Constant.KEY_RECEIVER_ID] = receiverUser["email"] as String
        message[Constant.KEY_MESSAGE] = binding.inputMessage.text.toString()
        message[Constant.KEY_TIMESTAMP] = Date()
        database.collection(Constant.KEY_COLLECTION_CHAT).add(message)
        binding.inputMessage.text = null
    }

    private fun listenMessages() {
        database.collection(Constant.KEY_COLLECTION_CHAT)
            .whereEqualTo(Constant.KEY_SENDER_ID, currentUserEmail)
            .whereEqualTo(Constant.KEY_RECEIVER_ID, receiverUser["email"] as String)
            .addSnapshotListener { value, error ->
                if (error != null) {
                    return@addSnapshotListener;
                }
                if (value != null) {
                    var count = chatMessages.size;
                    for (documentChange: DocumentChange in value.documentChanges) {
                        if (documentChange.type == DocumentChange.Type.ADDED) {
                            var chatMessage: ChatMessage = ChatMessage()
                            chatMessage.senderId =
                                documentChange.document.getString(Constant.KEY_SENDER_ID)!!;
                            chatMessage.receiverId =
                                documentChange.document.getString(Constant.KEY_RECEIVER_ID)!!;
                            chatMessage.message =
                                documentChange.document.getString(Constant.KEY_MESSAGE)!!;
                            chatMessage.dateTime =
                                getReadableDateTime(documentChange.document.getDate(Constant.KEY_TIMESTAMP)!!);
                            chatMessage.dateObject =
                                documentChange.document.getDate(Constant.KEY_TIMESTAMP)!!;
                            (chatMessages as ArrayList<ChatMessage>).add(chatMessage);
                        }
                    }

                    (chatMessages as ArrayList<ChatMessage>).sort()
                    if (count == 0) {
                        chatAdapter.notifyDataSetChanged()
                    } else {
                        chatAdapter.notifyItemRangeInserted(chatMessages.size, chatMessages.size)
                        binding.chatRecyclerView.smoothScrollToPosition(chatMessages.size - 1)
                    }
                    binding.chatRecyclerView.visibility = View.VISIBLE
                }
                binding.chatProgressBar.visibility = View.GONE
            }


        database.collection(Constant.KEY_COLLECTION_CHAT)
            .whereEqualTo(Constant.KEY_SENDER_ID, receiverUser["email"] as String)
            .whereEqualTo(Constant.KEY_RECEIVER_ID, currentUserEmail)
            .addSnapshotListener { value, error ->
                if (error != null) {
                    return@addSnapshotListener;
                }
                if (value != null) {
                    var count = chatMessages.size;
                    for (documentChange: DocumentChange in value.documentChanges) {
                        if (documentChange.type == DocumentChange.Type.ADDED) {
                            var chatMessage: ChatMessage = ChatMessage()
                            chatMessage.senderId =
                                documentChange.document.getString(Constant.KEY_SENDER_ID)!!;
                            chatMessage.receiverId =
                                documentChange.document.getString(Constant.KEY_RECEIVER_ID)!!;
                            chatMessage.message =
                                documentChange.document.getString(Constant.KEY_MESSAGE)!!;
                            chatMessage.dateTime =
                                getReadableDateTime(documentChange.document.getDate(Constant.KEY_TIMESTAMP)!!);
                            chatMessage.dateObject =
                                documentChange.document.getDate(Constant.KEY_TIMESTAMP)!!;
                            (chatMessages as ArrayList<ChatMessage>).add(chatMessage);
                        }
                    }
                    (chatMessages as ArrayList<ChatMessage>).sort()
                    if (count == 0) {
                        chatAdapter.notifyDataSetChanged()
                    } else {
                        chatAdapter.notifyItemRangeInserted(
                            chatMessages.size,
                            chatMessages.size
                        )
                        binding.chatRecyclerView.smoothScrollToPosition(chatMessages.size - 1)
                    }
                    binding.chatRecyclerView.visibility = View.VISIBLE
                }
                binding.chatProgressBar.visibility = View.GONE
            }


    }

    private fun getBitmapFromEncodedString(encodedImage: String) : Bitmap {
        val imageAsBytes = Base64.decode(encodedImage.toByteArray(), Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size)
    }


    private fun loadReceiverDetails() {
        receiverEmail = intent.getStringExtra("RECEIVER_EMAIL")!!
        val data = hashMapOf(
            "otherUserEmail" to receiverEmail,
            "currUserEmail" to currentUserEmail
        )
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getUserInfoForChat")
            .call(data)
            .addOnSuccessListener {
                println("successful $it")

                receiverUser = it.data as Map<String, *>
                binding.chatName.text = (receiverUser["displayName"].toString())
                if (receiverUser["relationType"].toString() == "friend") {
                    isFriend = true
                    println("debug: receiver user is friend")
                }
                init()
                listenMessages()

            }
            .addOnFailureListener {
                println("unsuccessful $it")

            }



    }

    private fun setListeners() {
        binding.imageBack.setOnClickListener { onBackPressed() }
        binding.layoutSend.setOnClickListener { sendMessage() }
        binding.imageGame.setOnClickListener { launchGameActivity() }
    }

    private fun launchGameActivity() {
        val data = hashMapOf(
            "currUserEmail" to currentUserEmail,
            "otherUserEmail" to receiverEmail
        )

        FirebaseFunctions.getInstance()
            .getHttpsCallable("getGameState")
            .call(data)
            .addOnSuccessListener {
                println("successful ${it.data}")
                val gameState = it.data


                if (gameState == null) {
                    println("should launch dialog")
                    val myDialog = GameSelectDialog()
                    val bundle = Bundle()
                    bundle.putInt(GameSelectDialog.DIALOG_KEY, GameSelectDialog.GAME_DIALOG)
                    bundle.putString(Constant.KEY_RECEIVER_ID, receiverEmail)
                    bundle.putBoolean(Constant.KEY_FRIEND, isFriend)
                    bundle.putString(Constant.OPP_DISPLAY_NAME, receiverUser["displayName"].toString())
                    myDialog.arguments = bundle
                    myDialog.show(supportFragmentManager, "tag")
                } else {
                    print("Existing gamestate\n")

                    val gson = GsonBuilder().create()
                    val retObj = gson.fromJson(gameState as String, GameState::class.java)
                    println("gamename ${retObj.gameName}")

                    if (retObj.gameName == "SnapThis") {
                        var intent = Intent(this, IntroPhotoRouletteActivity::class.java)
                        intent.putExtra(Constant.KEY_RECEIVER_ID, receiverEmail)
                        startActivity(intent)
                    } else if (retObj.gameName == "RockPaperScissors") {
                        var intent = Intent(this, RockPaperScissorActivity::class.java)
                        intent.putExtra(Constant.KEY_RECEIVER_ID, receiverEmail)
                        startActivity(intent)
                    } else if (retObj.gameName == "MatchCards") {
                        var intent = Intent(this, CardGameActivity::class.java)
                        intent.putExtra(Constant.KEY_RECEIVER_ID, receiverEmail)
                        intent.putExtra(Constant.OPP_DISPLAY_NAME, receiverUser["displayName"].toString())
                        startActivity(intent)
                    }
                }

            }
            .addOnFailureListener {
                println("unsuccessful $it")

            }




    }

    private fun getReadableDateTime(date: Date): String {
        return SimpleDateFormat("MMMM dd, yyyy - hh:mm a", Locale.getDefault()).format(date)
    }

}