package com.cmpt362.friendrr

object Constant {
    const val UID_KEY = "UID_KEY"
    const val EMAIL_KEY = "EMAIL_KEY"
    const val KEY_USER_ID = "userId"
    const val KEY_COLLECTION_CHAT = "chat"
    const val KEY_SENDER_ID = "senderId"
    const val KEY_RECEIVER_ID = "receiverId"
    const val KEY_MESSAGE = "message"
    const val KEY_FRIEND = "friend"
    const val KEY_TIMESTAMP = "timestamp"
    const val DISPLAY_NAME_KEY = "DISPLAY_NAME_KEY"
    const val BIRTHDATE_KEY = "BIRTHDATE_KEY"
    const val GENDER_KEY = "GENDER_KEY"
    const val SELECTED_HOBBIES_LIST = "SELECTED_HOBBIES_LIST"
    const val PROFILE_PIC_KEY = "PROFILE_PIC_KEY"
    val hobbiesList = arrayOf(
        "Art", "Beaches", "Board Games", "Camping", "Gym",
        "Hiking", "Music", "Reading", "Sports", "Video Games"
    )
    const val PROFILE_THREE_ACTIVITY = "PROFILE_THREE_ACTIVITY"
    const val EDIT_PROFILE_FRAGMENT = "EDIT_PROFILE_FRAGMENT"
    const val OTHER_USER_EMAIL_KEY = "OTHER_USER_EMAIL_KEY"
    const val OTHER_USER_DISPLAY_NAME_KEY = "OTHER_USER_DISPLAY_NAME_KEY"
    const val RELATIONSHIP_TYPE = "RELATIONSHIP_TYPE"
    const val BYTE_ARRAY_KEY = "BYTE_ARRAY_KEY"
    const val OPP_DISPLAY_NAME = "OPP_NAME"
}