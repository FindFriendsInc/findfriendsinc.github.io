package com.cmpt362.friendrr.viewMatch

class MatchUser(email: String, displayName: String, profilePicture: String, relationType: String) {
    private var email: String
    private var displayName: String
    private var profilePicture: String
    private var relationType: String

    init{
        this.email = email
        this.displayName = displayName
        this.profilePicture = profilePicture
        this.relationType = relationType
    }

    fun getEmail(): String {
        return email
    }

    fun getDisplayName(): String {
        return displayName
    }

    fun getProfilePicture(): String {
        return profilePicture
    }

    fun getRelationType(): String {
        return relationType
    }
}