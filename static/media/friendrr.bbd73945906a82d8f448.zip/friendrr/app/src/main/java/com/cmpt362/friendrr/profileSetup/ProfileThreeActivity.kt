package com.cmpt362.friendrr.profileSetup

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.MainActivity
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.query.ProfileQuery
import com.google.firebase.functions.FirebaseFunctions
import java.io.File
import java.lang.Exception

class ProfileThreeActivity : AppCompatActivity() {

    lateinit var cameraResult: ActivityResultLauncher<Intent>
    lateinit var galleryResult: ActivityResultLauncher<String>
    private lateinit var profileImgText: TextView
    private lateinit var photoBtn: Button
    private lateinit var nextBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var imgView: ImageView
    lateinit var tempImgUri: Uri
    private val fileName: String = "temp_file"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_three)

        val editProfileImg = intent.getBooleanExtra("edit_profile_img", false)

        imgView = findViewById(R.id.profile_image)
        photoBtn = findViewById(R.id.take_picture)
        photoBtn.setOnClickListener {
            val myDialog = PhotoDialogFragment(Constant.PROFILE_THREE_ACTIVITY)
            myDialog.show(supportFragmentManager, "Photo")
        }

        profileImgText = findViewById(R.id.profile_image_text)
        nextBtn = findViewById(R.id.next_btn)
        saveBtn = findViewById(R.id.save_btn)

        // Conditionally render the next and save buttons depending on how the activity was launched
        if (editProfileImg) {
            profileImgText.visibility = View.GONE
            nextBtn.visibility = View.GONE
            saveBtn.visibility = View.VISIBLE
            saveBtn.setOnClickListener {
                finish()
            }
        }
        else {
            nextBtn.setOnClickListener {
                nextBtn.isEnabled = false
                addProfileToDbAndMoveToMainActivity(ProfileHelper.getCurrentEmail(this))

            }
        }


        val tempImgFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), fileName)
        tempImgUri = FileProvider.getUriForFile(this, "com.cmpt362.friendrr", tempImgFile)
        cameraResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult())
        { result: ActivityResult ->
            if(result.resultCode == Activity.RESULT_OK){
                var bitmap = ProfileHelper.getBitmapHelper(this, tempImgUri)
                bitmap = Bitmap.createScaledBitmap(bitmap,200,200, true)
                imgView.setImageBitmap(bitmap)
                val encoded: String = bitmap.let { ProfileHelper.encodeBitmapHelper(it) }
                ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.PROFILE_PIC_KEY, encoded)

                // Enable the next and buttons after setting camera image
                enableNextButton()
                enableSaveButton()
            }
        }

        galleryResult = registerForActivityResult(ActivityResultContracts.GetContent()) { it ->
            try {
                var bitmap = ProfileHelper.getBitmapHelper(this, it)
                bitmap = Bitmap.createScaledBitmap(bitmap,200,200, true)
                val encoded: String? = bitmap.let { ProfileHelper.encodeBitmapHelper(it) }
                ProfileHelper.addCurrentProfileToLocalStorage(
                    this,
                    Constant.PROFILE_PIC_KEY,
                    encoded!!
                )
                imgView.setImageURI(it)

                // Enable the next and save buttons after setting gallery image
                enableNextButton()
                enableSaveButton()
            } catch (e:NullPointerException) {
                Log.e("Error: ", "Unable to fetch image from gallery")
            }
        }

        // Disable the next button until a photo is set
        disableNextButton()
        disableSaveButton()
    }

    private fun disableNextButton() {
        nextBtn.alpha = 0.6f
        nextBtn.isClickable = false
    }

    private fun enableNextButton() {
        nextBtn.alpha = 1f
        nextBtn.isClickable = true
    }

    private fun disableSaveButton() {
        saveBtn.alpha = 0.6f
        saveBtn.isClickable = false
    }

    private fun enableSaveButton() {
        saveBtn.alpha = 1f
        saveBtn.isClickable = true
    }

    private fun addProfileToDbAndMoveToMainActivity(email: String): Any {
        
        val sharedpref: SharedPreferences = this.getSharedPreferences("profileSetup",
            Context.MODE_PRIVATE)
        val displayName = sharedpref.getString(Constant.DISPLAY_NAME_KEY, "")!!
        val birthDate = sharedpref.getString(Constant.BIRTHDATE_KEY, "")!!
        val gender = sharedpref.getString(Constant.GENDER_KEY, "")!!
        val hobbiesList = sharedpref.getStringSet(Constant.SELECTED_HOBBIES_LIST, null)!!.toList()
        val profilePicture = sharedpref.getString(Constant.PROFILE_PIC_KEY, "")!!
        val voiceRecording = sharedpref.getString(Constant.BYTE_ARRAY_KEY, "")!!
        println("test yo: $hobbiesList")
        val data = HashMap<String, Any>()
        lateinit var retObj: Any
        data["email"] = email
        data["displayName"] = displayName
        data["birthDate"] = birthDate
        data["gender"] = gender
        data["hobbies"] = hobbiesList
        data["profilePicture"] = profilePicture
        data["voiceRecording"] = voiceRecording
        return try {
            FirebaseFunctions.getInstance()
                .getHttpsCallable("addProfile")
                .call(data)
                .addOnFailureListener {
                    nextBtn.isEnabled = true
                }
                .addOnSuccessListener {
                    println("success yo ${it.data}")
//                    ProfileHelper.clearCurrentProfileFromLocalStorage(activity)
                    Toast.makeText(this, "Profile has been saved!", Toast.LENGTH_LONG).show()
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                }
        }catch(e: Exception) {
            println(e)
        }
    }
}