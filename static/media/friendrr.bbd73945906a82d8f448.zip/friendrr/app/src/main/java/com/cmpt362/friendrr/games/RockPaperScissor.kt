package com.cmpt362.friendrr.games

class RockPaperScissor(userTurn:String, currScore: Int, currMove:String, otherMove: String, otherScore: Int, currEmail:String, otherEmail:String) {
    private var currUserScore:Int = 0
    private var turn:String = "Nothing"
    private var currUserMove: String = "Nothing"
    private var otherUserMove: String = "Nothing"
    private var otherUserScore: Int = 0
    private var currentUserEmail: String = ""
    private var otherUserEmail: String = ""
    private var gameName:String = "RockPaperScissors"

    init {
        currUserScore = currScore
        turn = userTurn
        currUserMove = currMove
        otherUserMove = otherMove
        otherUserScore = otherScore
        currentUserEmail = currEmail
        otherUserEmail = otherEmail
    }

    fun getCurrUserScore():Int{
        return currUserScore
    }

    fun getOtherUserScore():Int{
        return otherUserScore
    }

    fun getCurrMove():String{
        return currUserMove
    }

    fun getOtherUserMove():String{
        return otherUserMove
    }

    fun getTurn():String{
        return turn
    }

    fun getCurrEmail():String{
        return currentUserEmail
    }

    fun getOtherEmail():String{
        return otherUserEmail
    }

}