package com.cmpt362.friendrr.chat

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cmpt362.friendrr.databinding.ReceivedMessageItemContainerBinding
import com.cmpt362.friendrr.databinding.SentMessageItemContainerBinding

class ChatAdapter: RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final lateinit var chatMessages :List<ChatMessage>
    private final lateinit var receiverProfileImage: Bitmap
    private final lateinit var senderId: String

    public val VIEW_TYPE_SENT: Int = 1
    public val VIEW_TYPE_RECEIVED: Int = 2

    constructor(chatMessages: List<ChatMessage>, receiverProfileImage: Bitmap, senderId: String) {
        this.chatMessages = chatMessages
        this.receiverProfileImage = receiverProfileImage
        this.senderId = senderId
    }

    class SentMessageViewHolder : RecyclerView.ViewHolder {
        private final var binding: SentMessageItemContainerBinding

        constructor(sentMessageItemContainerBinding: SentMessageItemContainerBinding) : super(sentMessageItemContainerBinding.root) {
            binding = sentMessageItemContainerBinding
        }

        fun setData(chatMessage: ChatMessage) {
            binding.sentTextMessage.text = chatMessage.message
            binding.sentMessageDateTime.text = chatMessage.dateTime
        }
    }

    class ReceivedMessageViewHolder : RecyclerView.ViewHolder {
        private final var binding: ReceivedMessageItemContainerBinding

        constructor(receivedMessageItemContainerBinding: ReceivedMessageItemContainerBinding) : super(receivedMessageItemContainerBinding.root) {
            binding = receivedMessageItemContainerBinding
        }

        fun setData(chatMessage: ChatMessage, receiverProfileImage: Bitmap) {
            binding.receivedTextMessage.text = chatMessage.message
            binding.receivedMessageDateTime.text = chatMessage.dateTime
            binding.imageProfile.setImageBitmap(receiverProfileImage)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        if (viewType == VIEW_TYPE_SENT) {
            return SentMessageViewHolder(
                    SentMessageItemContainerBinding.inflate(
                        LayoutInflater.from(parent.context), parent, false
                    )
            )
        } else {
            return ReceivedMessageViewHolder(
                ReceivedMessageItemContainerBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
            )
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (getItemViewType(position) == VIEW_TYPE_SENT) {
            ((holder as (SentMessageViewHolder)).setData(chatMessages[position]))
        } else {
            ((holder as (ReceivedMessageViewHolder)).setData(chatMessages[position], receiverProfileImage))
        }
    }

    override fun getItemCount(): Int {
        return chatMessages.size
    }

    override fun getItemViewType(position: Int): Int {
        if (chatMessages[position].senderId == senderId) {
            return VIEW_TYPE_SENT
        } else {
            return VIEW_TYPE_RECEIVED
        }
    }
}