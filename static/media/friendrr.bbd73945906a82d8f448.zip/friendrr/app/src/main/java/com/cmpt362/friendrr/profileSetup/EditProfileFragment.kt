package com.cmpt362.friendrr.profileSetup


import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Base64
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.lifecycle.ViewModelProvider
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.GlobalViewModel
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.query.ProfileQuery
import com.cmpt362.friendrr.userAuthentication.LoginActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import java.io.File
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList


class EditProfileFragment : Fragment() {

    private lateinit var photoBtn: Button

    private lateinit var startRecordingBtn: Button
    private lateinit var replayRecordingBtn: Button
    private lateinit var mediaRecorder: MediaRecorder
    private lateinit var filepath: File
    private var isRecordingSet = false

    private lateinit var userName: EditText
    private lateinit var userBirthdate: EditText
    private lateinit var userGenderGroup: RadioGroup
    private lateinit var userFemale: RadioButton
    private lateinit var userMale: RadioButton
    private lateinit var userOther: RadioButton
    private lateinit var userHobbies: ListView
    private lateinit var saveBtn: Button
    private lateinit var logoutBtn: Button
    private lateinit var imgView: ImageView
    private lateinit var byteArrayRecording: ByteArray
    private lateinit var selectHobbiesList: ArrayList<String>

    private val calendar = Calendar.getInstance()

    private lateinit var globalViewModel: GlobalViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val editProfileFragmentView = inflater.inflate(R.layout.fragment_edit_profile, container, false)

        // Initializing gender
        userGenderGroup = editProfileFragmentView.findViewById(R.id.user_gender)
        userFemale = editProfileFragmentView.findViewById(R.id.user_female)
        userMale = editProfileFragmentView.findViewById(R.id.user_male)
        userOther = editProfileFragmentView.findViewById(R.id.user_other)
        selectHobbiesList = ArrayList<String>()

        imgView = editProfileFragmentView.findViewById(R.id.profile_image)


        // Profile Image setup
        photoBtn = editProfileFragmentView.findViewById(R.id.take_picture)
        photoBtn.setOnClickListener {
            val intent = Intent(requireActivity(), ProfileThreeActivity::class.java)
            intent.putExtra("edit_profile_img", true)
            startActivity(intent)
        }

        // Voice Recording setup
        startRecordingBtn = editProfileFragmentView.findViewById(R.id.start_recording)
        replayRecordingBtn = editProfileFragmentView.findViewById(R.id.replay_recording)

        startRecordingBtn.setOnClickListener {
            // Reset isRecordingSet so that the user cannot replay a recording while a recording is in progress
            isRecordingSet = false

            filepath = File(requireActivity().getExternalFilesDir(null), "friendrr_audio_recording.mp3")
            mediaRecorder = MediaRecorder()
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mediaRecorder.setOutputFile(filepath.toString())

            // Record for 5 seconds
            mediaRecorder.prepare()
            mediaRecorder.start()
            object : CountDownTimer(5000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    // Show progress bar here or seconds remaining
                }

                // After 5 seconds stop the recording and show a toast to user
                override fun onFinish() {
                    mediaRecorder.stop()
                    mediaRecorder.reset()
                    mediaRecorder.release()
                    Toast.makeText(requireActivity().applicationContext, "Recording complete", Toast.LENGTH_LONG).show()
                    isRecordingSet = true
                    val encode = ProfileHelper.convertMp3toByteArrayString(requireActivity(), filepath)
                    byteArrayRecording = Base64.decode(encode, 0)
                    ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.BYTE_ARRAY_KEY, encode)
                }
            }.start()
        }

        // Replay button only works if a recording has been set
        replayRecordingBtn.setOnClickListener {
            if (isRecordingSet) {
//                mediaPlayer = MediaPlayer()
//                mediaPlayer.setDataSource(filepath.toString())
//                mediaPlayer.prepare()
//                mediaPlayer.start()

                ProfileHelper.playMp3(requireActivity(), byteArrayRecording, File(requireActivity().getExternalFilesDir(null), "friendrr_audio_recording.mp3"))


            }
        }

        // General user information setup
        // Get the user information and set it as the inputs
        userName = editProfileFragmentView.findViewById(R.id.user_name)

        userBirthdate = editProfileFragmentView.findViewById(R.id.user_birthdate)
        val datePickerDialog = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, monthOfYear)
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateLabel()
        }

        userHobbies = editProfileFragmentView.findViewById(R.id.hobbies_list)
        userHobbies.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        val arrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(requireActivity(),
            R.layout.list_item_multiple_choice, Constant.hobbiesList)
        userHobbies.adapter = arrayAdapter
        userHobbies.onItemClickListener =
            AdapterView.OnItemClickListener { parent, view, position, id ->

                if (selectHobbiesList.contains(Constant.hobbiesList[position])) {
                    selectHobbiesList.removeIf { it === Constant.hobbiesList[position] }
                } else {
                    selectHobbiesList.add(Constant.hobbiesList[position])
                }
            }

        userBirthdate.setOnClickListener {
            DatePickerDialog(requireActivity(), datePickerDialog, calendar.get(Calendar.YEAR), calendar.get(
                Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        saveBtn = editProfileFragmentView.findViewById(R.id.save_btn)
        saveBtn.setOnClickListener {
            if (verifyFields()) {
                // Save user's changes
                ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.DISPLAY_NAME_KEY, userName.text.toString())
                ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.BIRTHDATE_KEY, userBirthdate.text.toString())
                selectGenderHelper()
                var set = HashSet<String>()
                set.addAll(selectHobbiesList)
                ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.SELECTED_HOBBIES_LIST, set)
                ProfileQuery.addProfileToDb(requireActivity(), ProfileHelper.getCurrentEmail(requireActivity()))
            }
        }

        logoutBtn = editProfileFragmentView.findViewById(R.id.logout_btn)
        logoutBtn.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            val intent = Intent(requireActivity(), LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        getProfileInfo(ProfileHelper.getCurrentEmail(requireActivity()))

        globalViewModel = ViewModelProvider(requireActivity()).get(GlobalViewModel::class.java)
        globalViewModel.setLoadingStatus(true)

        return editProfileFragmentView
    }

    private fun updateLabel() {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.CANADA)
        userBirthdate.setText(dateFormat.format(calendar.time))
    }

    private fun getProfileInfo(email: String): Any {
        
        val data = HashMap<String, Any>()
        lateinit var retObj: Map<String, *>
        data["email"] = email
        return try {
            FirebaseFunctions.getInstance()
                .getHttpsCallable("getProfile")
                .call(data)
                .addOnFailureListener {
                    globalViewModel.setLoadingStatus(false)
                    println("gg yo $it")
                }
                .addOnSuccessListener {
                    retObj = it.data as Map<String, *>
                    userName.setText(retObj["displayName"].toString())
                    userBirthdate.setText(retObj["birthDate"].toString())
                    val genderSelection = retObj["gender"]
                    val selectedHobbyItems = retObj["hobbies"] as ArrayList<*>
                    val encodedRecording = retObj["voiceRecording"].toString()
                    byteArrayRecording = Base64.decode(encodedRecording, 0)


                    if (genderSelection == "Male") {
                        userMale.isChecked = true
                    } else if (genderSelection == "Female")
                    {
                        userFemale.isChecked = true
                    } else if (genderSelection == "Other") {
                        userOther.isChecked = true
                    }

                    for (hobby in selectedHobbyItems) {
                        userHobbies.setItemChecked(Constant.hobbiesList.indexOf(hobby), true)
                        selectHobbiesList.add(Constant.hobbiesList[Constant.hobbiesList.indexOf(hobby)])
                    }
                    ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.PROFILE_PIC_KEY, retObj["profilePicture"] as Any)
                    val imageAsBytes = Base64.decode(retObj["profilePicture"].toString().toByteArray(), Base64.DEFAULT)
                    imgView.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size))
                    globalViewModel.setLoadingStatus(false)
                }
        } catch (e: Exception) {
            println(e)
        }
    }

    private fun selectGenderHelper () {
        if(userFemale.isChecked) {
            ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.GENDER_KEY, "Female")
        } else if(userMale.isChecked) {
            ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.GENDER_KEY, "Male")
        } else if(userOther.isChecked) {
            ProfileHelper.addCurrentProfileToLocalStorage(requireActivity(), Constant.GENDER_KEY, "Other")
        }
    }

    private fun verifyFields(): Boolean {
        // Check username
        if (userName.text.isEmpty()) {
            Toast.makeText(requireActivity(), "Please enter a username", Toast.LENGTH_LONG).show()
            return false
        }
        // Check birthdate
        else if (userBirthdate.text.isEmpty()) {
            Toast.makeText(requireActivity(), "Please enter your birthdate", Toast.LENGTH_LONG).show()
            return false
        }
        // Check gender
        else if (userGenderGroup.checkedRadioButtonId == -1) {
            Toast.makeText(requireActivity(), "Please select a gender", Toast.LENGTH_LONG).show()
            return false
        }
        // Check hobbies list has at least one option selected
        else if (selectHobbiesList.isEmpty()) {
            Toast.makeText(requireActivity(), "Please select at least one hobby", Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }
}