package com.cmpt362.friendrr.games

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.lifecycle.ViewModelProvider
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.ktx.functions
import com.google.firebase.ktx.Firebase
import com.google.gson.Gson

class RockPaperScissorActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var rockBtn: Button
    private lateinit var paperBtn: Button
    private lateinit var scissorButton: Button
    private lateinit var exitButton:Button
    private lateinit var functions: FirebaseFunctions
    private lateinit var rockPaperScissor: RockPaperScissor
    private lateinit var viewModel: RockPaperScissorViewModel
    private lateinit var otherPic: ImageView
    private lateinit var playerTurnText: TextView
    private lateinit var curUserText: TextView
    private lateinit var otherUserText: TextView
    private var cUser = ""
    private var oUser = ""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rock_paper_scissor)

        
        viewModel = ViewModelProvider(this).get(RockPaperScissorViewModel::class.java)
        rockBtn = findViewById(R.id.rockButton)
        paperBtn = findViewById(R.id.paperButton)
        scissorButton = findViewById(R.id.scissorButton)
        otherPic = findViewById(R.id.otherPlayer)
        curUserText = findViewById(R.id.yourScore)
        otherUserText = findViewById(R.id.oppScore)
        playerTurnText = findViewById(R.id.yourTurnText)
        exitButton = findViewById(R.id.exitBtn)
        functions = Firebase.functions

        rockBtn.setOnClickListener(this)
        paperBtn.setOnClickListener(this)
        scissorButton.setOnClickListener(this)
        exitButton.setOnClickListener(this)

        rockPaperScissor = RockPaperScissor("", 0, "Nothing", "Nothing", 0, "", "")

        cUser = ProfileHelper.getCurrentEmail(this)

        //getting opponent email from intent
        oUser = intent.getStringExtra(Constant.KEY_RECEIVER_ID)!!


        if (savedInstanceState == null) {
            callGameStateFunction(cUser, oUser)
        }

        viewModel.rockPaperScissorObj.observe(this) {
            if(it != null){
                val gson = Gson()
                rockPaperScissor = gson.fromJson(it, RockPaperScissor::class.java)

                val otherEmail = rockPaperScissor.getOtherEmail()
                val curEmail = rockPaperScissor.getCurrEmail()

                if (cUser == rockPaperScissor.getCurrEmail()) {
                    val curUserTexts = "Your Score: ${rockPaperScissor.getCurrUserScore()}"
                    curUserText.text = curUserTexts
                    val oppUserText = "Opponent Score: ${rockPaperScissor.getOtherUserScore()}"
                    otherUserText.text = oppUserText
                    setImage(rockPaperScissor.getCurrMove())
                } else {
                    val oppUserTexts = "Your Score: ${rockPaperScissor.getOtherUserScore()}"
                    otherUserText.text = oppUserTexts

                    val curUserTexts = "Opponent Score: ${rockPaperScissor.getCurrUserScore()}"
                    curUserText.text = curUserTexts

                    setImage(rockPaperScissor.getOtherUserMove())
                }

                if (rockPaperScissor.getOtherUserScore() == 3 && cUser == rockPaperScissor.getOtherEmail()) {
                    callDeleteGameFunction(curEmail, otherEmail, "RPS", otherEmail, curEmail)
                    Toast.makeText(this, "You Win", Toast.LENGTH_LONG).show()
                    finish()
                }
                if (rockPaperScissor.getCurrUserScore() == 3 && cUser == rockPaperScissor.getCurrEmail()) {
                    callDeleteGameFunction(curEmail, otherEmail, "RPS", curEmail, otherEmail)
                    Toast.makeText(this, "You Win", Toast.LENGTH_LONG).show()
                    finish()
                }
                if (rockPaperScissor.getCurrUserScore() == 3 && cUser == rockPaperScissor.getOtherEmail()) {
                    callDeleteGameFunction(curEmail, otherEmail, "RPS", curEmail, otherEmail)
                    Toast.makeText(this, "You Lose", Toast.LENGTH_LONG).show()
                    finish()
                }
                if (rockPaperScissor.getOtherUserScore() == 3 && cUser == rockPaperScissor.getCurrEmail()) {
                    callDeleteGameFunction(curEmail, otherEmail, "RPS", otherEmail, curEmail)
                    Toast.makeText(this, "You Lose", Toast.LENGTH_LONG).show()
                    finish()
                }


                val firstUserEmail = rockPaperScissor.getCurrEmail()
                if (rockPaperScissor.getCurrMove() != "Nothing" && rockPaperScissor.getOtherUserMove() != "Nothing") {
                    val currMove = rockPaperScissor.getCurrMove()
                    val otherMove = rockPaperScissor.getOtherUserMove()


                    if (currMove == "Rock" && otherMove == "Scissor") {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore() + 1,
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore(),
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    } else if (currMove == "Scissor" && otherMove == "Paper") {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore() + 1,
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore(),
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    } else if (currMove == "Paper" && otherMove == "Rock") {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore() + 1,
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore(),
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    } else if (currMove == otherMove) {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore(),
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore(),
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    }

                    if (otherMove == "Rock" && currMove == "Scissor") {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore(),
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore() + 1,
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    } else if (otherMove == "Scissor" && currMove == "Paper") {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore(),
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore() + 1,
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    } else if (otherMove == "Paper" && currMove == "Rock") {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore(),
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore() + 1,
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    } else if (otherMove == currMove) {
                        rockPaperScissor = RockPaperScissor(
                            firstUserEmail,
                            rockPaperScissor.getCurrUserScore(),
                            "Nothing",
                            "Nothing",
                            rockPaperScissor.getOtherUserScore(),
                            rockPaperScissor.getCurrEmail(),
                            rockPaperScissor.getOtherEmail()
                        )
                    }

                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    callUpdateGameFunction(
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail(),
                        jsonString
                    )

                }

                if (rockPaperScissor.getTurn() != cUser) {
                    val notYourTurnText = "Not Your Turn!, Exit!"
                    playerTurnText.text = notYourTurnText
                    rockBtn.isEnabled = false
                    paperBtn.isEnabled = false
                    scissorButton.isEnabled = false
                } else{
                    val yourTurnText = "First to 3 Wins!"
                    playerTurnText.text = yourTurnText
                }

                if (rockPaperScissor.getOtherUserMove() == "Scissor" && cUser == otherEmail) {
                    otherPic.setImageResource(R.drawable.ic_scissors_svgrepo_com)
                }
                if (rockPaperScissor.getOtherUserMove() == "Paper" && cUser == otherEmail) {
                    otherPic.setImageResource(R.drawable.ic_paper_plane_svgrepo_com)
                }
                if (rockPaperScissor.getOtherUserMove() == "Rock" && cUser == otherEmail) {
                    otherPic.setImageResource(R.drawable.ic_rock_svgrepo_com)
                }

                if (rockPaperScissor.getCurrMove() == "Scissor" && cUser == curEmail) {
                    otherPic.setImageResource(R.drawable.ic_scissors_svgrepo_com)
                }
                if (rockPaperScissor.getCurrMove() == "Paper" && cUser == curEmail) {
                    otherPic.setImageResource(R.drawable.ic_paper_plane_svgrepo_com)
                }
                if (rockPaperScissor.getCurrMove() == "Rock" && cUser == curEmail) {
                    otherPic.setImageResource(R.drawable.ic_rock_svgrepo_com)
                }


            }

        }

    }

    override fun onClick(view: View?) {
        val currEmail = rockPaperScissor.getCurrEmail()
        val otherEmail = rockPaperScissor.getOtherEmail()
        when (view?.id) {
            R.id.rockButton -> {
                if (rockPaperScissor.getTurn() == currEmail && cUser == currEmail) {
                    rockPaperScissor = RockPaperScissor(
                        otherEmail,
                        rockPaperScissor.getCurrUserScore(),
                        "Rock",
                        rockPaperScissor.getOtherUserMove(),
                        rockPaperScissor.getOtherUserScore(),
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail()
                    )
                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    callUpdateGameFunction(currEmail, otherEmail, jsonString)
                    otherPic.setImageResource(R.drawable.ic_rock_svgrepo_com)
                } else if (rockPaperScissor.getTurn() == otherEmail && cUser == otherEmail) {
                    rockPaperScissor = RockPaperScissor(
                        currEmail,
                        rockPaperScissor.getCurrUserScore(),
                        rockPaperScissor.getCurrMove(),
                        "Rock",
                        rockPaperScissor.getOtherUserScore(),
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail()
                    )
                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    callUpdateGameFunction(currEmail, otherEmail, jsonString)
                    otherPic.setImageResource(R.drawable.ic_rock_svgrepo_com)
                }

                finish()
            }
            R.id.paperButton -> {
                if (rockPaperScissor.getTurn() == currEmail && cUser == currEmail) {
                    rockPaperScissor = RockPaperScissor(
                        otherEmail,
                        rockPaperScissor.getCurrUserScore(),
                        "Paper",
                        rockPaperScissor.getOtherUserMove(),
                        rockPaperScissor.getOtherUserScore(),
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail()
                    )
                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    callUpdateGameFunction(currEmail, otherEmail, jsonString)
                    otherPic.setImageResource(R.drawable.ic_paper_plane_svgrepo_com)
                } else if (rockPaperScissor.getTurn() == otherEmail && cUser == otherEmail) {
                    rockPaperScissor = RockPaperScissor(
                        currEmail,
                        rockPaperScissor.getCurrUserScore(),
                        rockPaperScissor.getCurrMove(),
                        "Paper",
                        rockPaperScissor.getOtherUserScore(),
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail()
                    )
                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    callUpdateGameFunction(currEmail, otherEmail, jsonString)
                    otherPic.setImageResource(R.drawable.ic_paper_plane_svgrepo_com)
                }
                finish()
            }
            R.id.scissorButton -> {
                if (rockPaperScissor.getTurn() == currEmail && cUser == currEmail) {
                    rockPaperScissor = RockPaperScissor(
                        otherEmail,
                        rockPaperScissor.getCurrUserScore(),
                        "Scissor",
                        rockPaperScissor.getOtherUserMove(),
                        rockPaperScissor.getOtherUserScore(),
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail()
                    )
                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    callUpdateGameFunction(currEmail, otherEmail, jsonString)
                    otherPic.setImageResource(R.drawable.ic_scissors_svgrepo_com)
                } else if (rockPaperScissor.getTurn() == otherEmail && cUser == otherEmail) {
                    rockPaperScissor = RockPaperScissor(
                        currEmail,
                        rockPaperScissor.getCurrUserScore(),
                        rockPaperScissor.getCurrMove(),
                        "Scissor",
                        rockPaperScissor.getOtherUserScore(),
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail()
                    )
                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    callUpdateGameFunction(currEmail, otherEmail, jsonString)
                    otherPic.setImageResource(R.drawable.ic_scissors_svgrepo_com)
                }
                finish()
            }
            R.id.exitBtn ->{
                finish()
            }
        }
    }

    private fun setImage(move: String) {
        if (move == "Rock") {
            otherPic.setImageResource(R.drawable.ic_rock_svgrepo_com)
        } else if (move == "Paper") {
            otherPic.setImageResource(R.drawable.ic_paper_plane_svgrepo_com)
        } else if (move == "Scissor") {
            otherPic.setImageResource(R.drawable.ic_scissors_svgrepo_com)
        } else {
            otherPic.setImageResource(R.drawable.ic_question_mark_svgrepo_com)
        }
    }

    private fun callGameStateFunction(email: String, otherUserEmail: String) {
        val data = hashMapOf(
            "currUserEmail" to email,
            "otherUserEmail" to otherUserEmail
        )
        lateinit var retObj: String
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getGameState")
            .call(data)
            .addOnSuccessListener {
                val ret = it.data
                if (ret == null) {
                    rockPaperScissor =
                        RockPaperScissor(email, 0, "Nothing", "Nothing", 0, email, otherUserEmail)
                    val gson = Gson()
                    val jsonString = gson.toJson(rockPaperScissor)
                    viewModel.rockPaperScissorObj.value = jsonString
                    callUpdateGameFunction(
                        rockPaperScissor.getCurrEmail(),
                        rockPaperScissor.getOtherEmail(),
                        jsonString
                    )
                    println("null")
                } else {
                    retObj = it.data as String
                    viewModel.rockPaperScissorObj.value = retObj
                    val gson = Gson()
                    rockPaperScissor = gson.fromJson(retObj, RockPaperScissor::class.java)
                }
            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }

    private fun callUpdateGameFunction(email: String, otherUserEmail: String, jsonString: String) {
        val data = hashMapOf(
            "currUserEmail" to email,
            "otherUserEmail" to otherUserEmail,
            "gameState" to jsonString
        )
        FirebaseFunctions.getInstance()
            .getHttpsCallable("updateGameState")
            .call(data)
            .addOnSuccessListener {
                println("success ${it.data}")
            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }

    private fun callDeleteGameFunction(email: String, otherUserEmail: String, gameType: String, winEmail: String, loseEmail:String) {
        val data = hashMapOf(
            "currUserEmail" to email,
            "otherUserEmail" to otherUserEmail,
            "gameType" to gameType,
            "winEmail" to winEmail,
            "loseEmail" to loseEmail
        )
        FirebaseFunctions.getInstance()
            .getHttpsCallable("deleteGameState")
            .call(data)
            .addOnSuccessListener {
                println("success ${it.data}")
            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }

}