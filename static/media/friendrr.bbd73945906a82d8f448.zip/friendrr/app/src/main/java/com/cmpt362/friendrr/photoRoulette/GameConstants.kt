package com.cmpt362.friendrr.photoRoulette

object GameConstants {
    val guessWords = arrayOf(
        "chair", "tree", "table", "water", "sad", "happy",
        "angry", "car", "kid", "laptop", "salad",
        "bus", "train", "noodles", "sneakers", "gloves", "masks",
        "wheels", "shirt", "pants", "socks", "phone", "nap", "mouth",
        "eye", "standing", "t-pose"
    )
    const val NEW_GAME_KEY = "NEW_GAME_KEY"
    const val NEW_GAME = "NEW_GAME"
    const val EXISTING_GAME_KEY = "EXISTING_GAME_KEY"
    const val EXISTING_GAME = "EXISTING_GAME"
    const val ROUNDS_KEY = "ROUNDS_KEY"
}