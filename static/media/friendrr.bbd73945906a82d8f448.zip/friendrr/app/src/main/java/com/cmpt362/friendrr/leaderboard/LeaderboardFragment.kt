package com.cmpt362.friendrr.leaderboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.cmpt362.friendrr.GlobalViewModel
import com.cmpt362.friendrr.R
import com.google.firebase.functions.FirebaseFunctions

class LeaderboardFragment:Fragment() {

    private lateinit var arrayList: ArrayList<Map<String, *>>
    private lateinit var arrayAdapter:LeaderboardListAdapter
    private lateinit var listView: ListView
    private lateinit var globalViewModel: GlobalViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_leaderboard, container, false)
        arrayList = ArrayList()
        listView = view.findViewById(R.id.list)
        globalViewModel = ViewModelProvider(requireActivity()).get(GlobalViewModel::class.java)


        globalViewModel.setLoadingStatus(true)
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getLeaderboard")
            .call()
            .addOnSuccessListener {
                println("success: ${it.data}")
                arrayList = it.data as ArrayList<Map<String, *>>
                arrayAdapter = LeaderboardListAdapter(requireActivity(), arrayList)
                listView.adapter = arrayAdapter
                globalViewModel.setLoadingStatus(false)
            }
            .addOnFailureListener {
                println("unsuccessful $it")
                globalViewModel.setLoadingStatus(false)
            }
        return view
    }
}