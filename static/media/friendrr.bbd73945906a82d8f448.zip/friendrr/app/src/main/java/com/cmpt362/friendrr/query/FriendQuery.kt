package com.cmpt362.friendrr.query

import android.app.Activity
import com.cmpt362.friendrr.MainActivity
import com.cmpt362.friendrr.friendMatch.SwipeAdapter
import com.google.firebase.functions.FirebaseFunctions

object FriendQuery {
    fun rightSwipe(activity: Activity, currentEmail: String, otherEmail: String) {
        

        val data = HashMap<String, Any>()
        data["email"] = currentEmail
        data["otherUserEmail"] = otherEmail
        FirebaseFunctions.getInstance()
            .getHttpsCallable("rightSwipe")
            .call(data)
            .addOnSuccessListener {
                println("success ${it.data}")
            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }
}