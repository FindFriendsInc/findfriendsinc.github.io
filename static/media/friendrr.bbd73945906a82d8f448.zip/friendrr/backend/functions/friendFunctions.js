const functions = require("firebase-functions");
const admin = require("firebase-admin");
const firestore = admin.firestore();
if (!admin.apps.length) {
    admin.initializeApp();
}
exports.rightSwipe = functions.https.onCall( async (data, context) => {
    const snap = await firestore.collection("users").where("email", "==", data.email).get();
    const otherUserSnap = await firestore.collection("users").where("email", "==", data.otherUserEmail).get();
    //before adding outgoing edge, checks to make sure if there exists incoming edge from the user
    snap.forEach(doc => {
        let incomingRightSwipeList = doc.data().incomingRightSwipeList;
        let matchedCandidateList = doc.data().matchedCandidateList;
        //this means the otherUserEmail has already swipped right on the current user. and current user now has swiped right
        //on the otherUserEmail. Now need to add both of them to matchedCandidateList then remove the otherUserEmail from
        //incomingRightSwipe(on current user) and remove email from outgoingRightSwipe(on otheruser side)
        if(incomingRightSwipeList.includes(data.otherUserEmail)) { 
            let specialCaseBatch = firestore.batch();
            incomingRightSwipeList = incomingRightSwipeList.filter(x => x !== data.otherUserEmail);
            matchedCandidateList.push(data.otherUserEmail);

            const ref = admin.firestore()
            .collection('users')
            .doc(doc.id);
            specialCaseBatch.update(ref, {
                incomingRightSwipeList: incomingRightSwipeList,
                matchedCandidateList: matchedCandidateList,
            });
            specialCaseBatch.commit();

            //now remove outgoingRightSwipe on otherUser side and add current user email to candidate list
            otherUserSnap.forEach(doc => {
                let otherUserOutGoingRightSwipe = doc.data().outgoingRightSwipeList;
                let otherUserMatchedCandidateList = doc.data().matchedCandidateList;
                otherUserOutGoingRightSwipe = otherUserOutGoingRightSwipe.filter( x => x != data.email);//test here
                otherUserMatchedCandidateList.push(data.email);
                let specialCaseBatch2 = firestore.batch();
                const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
                specialCaseBatch2.update(ref, {
                    outgoingRightSwipeList: otherUserOutGoingRightSwipe,
                    matchedCandidateList: otherUserMatchedCandidateList,
                });
                specialCaseBatch2.commit();
            });
            return {stat: "success"}
        }else{
            //if there does not exists an incoming edge of the current user assosciated with the otherUserEmail, then 
            //add outgoing edge

            let batch1 = firestore.batch();
            snap.forEach(doc => {
                let outgoingRightSwipeList = doc.data().outgoingRightSwipeList;
                if(!outgoingRightSwipeList.includes(data.otherUserEmail)) {
                    outgoingRightSwipeList.push(data.otherUserEmail);
                }
                const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
                batch1.update(ref, {
                    outgoingRightSwipeList: outgoingRightSwipeList,
                });
            });
            batch1.commit();

            let batch2 = firestore.batch();
            //creates a relationship edge between current user and the other user that current user swiped right
            otherUserSnap.forEach(doc => {
                let incomingRightSwipeList = doc.data().incomingRightSwipeList;
                if(!incomingRightSwipeList.includes(data.email)) {
                    incomingRightSwipeList.push(data.email);
                }
                const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
                batch2.update(ref, {
                    incomingRightSwipeList: incomingRightSwipeList,
                });
            });
            batch2.commit();
            return {stat: "success"}

        }
    });
});

exports.getCandidateAndFriendList = functions.https.onCall( async (data, context) => {
    const snapshot = await firestore.collection("users").where("email", "==", data.email).get();
    let userObjList = {};
    snapshot.docs.map((doc) => { //exists only one user of a given email in the database, will have only one iteration
        userObjList.matchedCandidateList = doc.data().matchedCandidateList;
        userObjList.friendList = doc.data().friendList;
    });

    let retList = [];
    
    if(userObjList.matchedCandidateList){
        for(let i = 0 ; i < userObjList.matchedCandidateList.length; i++) {
            let userInfoObj = await retrieveUserInfo(userObjList.matchedCandidateList[i]);
            let retObj = {};
            retObj.profilePicture = userInfoObj.profilePicture;
            retObj.displayName = userInfoObj.displayName;
            retObj.email = userInfoObj.email;
            retObj.relationType = 'friendCandidate';
            retList.push(retObj);
        }
    }
    
    if(userObjList.friendList){
        for(let i = 0 ; i < userObjList.friendList.length; i++) {
            let userInfoObj = await retrieveUserInfo(userObjList.friendList[i]);
            let retObj = {};
            retObj.profilePicture = userInfoObj.profilePicture;
            retObj.displayName = userInfoObj.displayName;
            retObj.email = userInfoObj.email;
            retObj.relationType = 'friend';
            retList.push(retObj);
        }
    }
    console.log(retList);
    //combines candidatelist and friendlist together with pic,displayname,email,photo and relationship type
    return retList;
});

exports.getUserInfoForChat = functions.https.onCall( async (data, context) => {
    const snapshot = await firestore.collection("users").where("email", "==", data.otherUserEmail).get();
    let obj = {};
    let otherUserFriendList = {};
    snapshot.docs.map((doc) => { //exists only one user of a given email in the database, will have only one iteration
        obj.email = doc.data().email;
        obj.displayName = doc.data().displayName;
        obj.hobbies = doc.data().hobbies;
        obj.profilePicture = doc.data().profilePicture;
        obj.relationType = 'friendCandidate';

        // Get if other user is a friend or friend candidate
        otherUserFriendList = doc.data().friendList;
        if(otherUserFriendList){
            for(let i = 0 ; i < otherUserFriendList.length; i++) {
                if (otherUserFriendList[i] == data.currUserEmail) {
                    obj.relationType = 'friend'
                }
            }
        }
    });
    return obj;
});

exports.friendRequest = functions.https.onCall( async (data, context) => {
    const snap = await firestore.collection("users").where("email", "==", data.email).get();
    const otherUserSnap = await firestore.collection("users").where("email", "==", data.otherUserEmail).get();
    //before adding outgoing edge, checks to make sure if there exists incoming edge from the user
    snap.forEach(doc => {
        let incomingFriendRequestList = doc.data().incomingFriendRequestList;
        let currUserOutgoingfriedRequestList = doc.data().outgoingFriendRequestList;
        let friendList = doc.data().friendList;
        let currUserCandidateList = doc.data().matchedCandidateList;

        //first checks if user has sent a friend request already. if it did, then stop this entire process
        if(currUserOutgoingfriedRequestList.includes(data.otherUserEmail)){
            return 'success: user has already sent request to the otherUser';
        }
        
        //this means the otherUserEmail has already swipped right on the current user. and current user now has added
        // the otherUserEmail. Now need to add both of them to friendlist then remove the otherUserEmail from
        //incoming friend request(on current user) and remove email from outgoing friend request(on otheruser side)
        else if (incomingFriendRequestList.includes(data.otherUserEmail)) { 
            let specialCaseBatch = firestore.batch();
            incomingFriendRequestList = incomingFriendRequestList.filter(x => x !== data.otherUserEmail);
            currUserCandidateList = currUserCandidateList.filter( x => x != data.otherUserEmail);
            friendList.push(data.otherUserEmail);

            const ref = admin.firestore()
            .collection('users')
            .doc(doc.id);
            specialCaseBatch.update(ref, {
                incomingFriendRequestList: incomingFriendRequestList,
                friendList: friendList,
                matchedCandidateList: currUserCandidateList,
            });
            specialCaseBatch.commit();

            //now remove outgoing friend request on otherUser side and add current user email to friend list
            otherUserSnap.forEach(doc => {
                let otherUserOutgoingFriendRequestList = doc.data().outgoingFriendRequestList;
                let otherUserFriendList = doc.data().friendList;
                let otherUserCandidateList = doc.data().matchedCandidateList;
                otherUserOutgoingFriendRequestList = otherUserOutgoingFriendRequestList.filter( x => x !== data.email);
                otherUserCandidateList = otherUserCandidateList.filter( x => x !== data.email);
                otherUserFriendList.push(data.email);
                let specialCaseBatch2 = firestore.batch();
                const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
                specialCaseBatch2.update(ref, {
                    outgoingFriendRequestList: otherUserOutgoingFriendRequestList,
                    friendList: otherUserFriendList,
                    matchedCandidateList: otherUserCandidateList, 
                });
                specialCaseBatch2.commit();
            });
            return {stat: "success"}
        }else{
            //if there does not exists an incoming edge of the current user assosciated with the otherUserEmail, then 
            //add outgoing edge

            let batch1 = firestore.batch();
            snap.forEach(doc => {
                let outgoingFriendRequestList = doc.data().outgoingFriendRequestList;
                if(!outgoingFriendRequestList.includes(data.otherUserEmail)) {
                    outgoingFriendRequestList.push(data.otherUserEmail);
                }
                const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
                batch1.update(ref, {
                    outgoingFriendRequestList: outgoingFriendRequestList,
                });
            });
            batch1.commit();

            let batch2 = firestore.batch();
            //creates a relationship edge between current user and the other user that current user swiped right
            otherUserSnap.forEach(doc => {
                let incomingFriendRequestList = doc.data().incomingFriendRequestList;
                if(!incomingFriendRequestList.includes(data.email)) {
                    incomingFriendRequestList.push(data.email);
                }
                const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
                batch2.update(ref, {
                    incomingFriendRequestList: incomingFriendRequestList,
                });
            });
            batch2.commit();
            return {stat: "success"}

        }
    });
});

exports.removeFriend = functions.https.onCall( async (data, context) => {
    const snap = await firestore.collection("users").where("email", "==", data.email).get();
    const otherUserSnap = await firestore.collection("users").where("email", "==", data.otherUserEmail).get();

    let batch1 = firestore.batch();
    snap.forEach(doc => {
        let friendList = doc.data().friendList;
        friendList = friendList.filter(x => x !== data.otherUserEmail);
        const ref = admin.firestore()
        .collection('users')
        .doc(doc.id);
        batch1.update(ref, {
            friendList: friendList,
        });
    });
    batch1.commit();

    let batch2 = firestore.batch();
    otherUserSnap.forEach(doc => {
        let friendList = doc.data().friendList;
        friendList = friendList.filter(x => x !== data.email);
        const ref = admin.firestore()
        .collection('users')
        .doc(doc.id);
        batch2.update(ref, {
            friendList: friendList,
        });
    });
    batch2.commit();

    return 'success';
});

exports.removeMatchedCandidate = functions.https.onCall( async (data, context) => {
    const snap = await firestore.collection("users").where("email", "==", data.email).get();
    const otherUserSnap = await firestore.collection("users").where("email", "==", data.otherUserEmail).get();

    let batch1 = firestore.batch();
    snap.forEach(doc => {
        let matchedCandidateList = doc.data().matchedCandidateList;
        matchedCandidateList = matchedCandidateList.filter(x => x !== data.otherUserEmail);
        const ref = admin.firestore()
        .collection('users')
        .doc(doc.id);
        batch1.update(ref, {
            matchedCandidateList: matchedCandidateList,
        });
    });
    batch1.commit();

    let batch2 = firestore.batch();
    otherUserSnap.forEach(doc => {
        let matchedCandidateList = doc.data().matchedCandidateList;
        matchedCandidateList = matchedCandidateList.filter(x => x !== data.email);
        const ref = admin.firestore()
        .collection('users')
        .doc(doc.id);
        batch2.update(ref, {
            matchedCandidateList: matchedCandidateList,
        });
    });
    batch2.commit();

    return 'success';
});

async function retrieveUserInfo(email){
    const snapshot =  await firestore.collection("users").where("email", "==", email).get();
    let obj = {};
    snapshot.docs.map((doc) => { //exists only one user of a given email in the database, will have only one iteration
        obj.email = doc.data().email;
        obj.displayName = doc.data().displayName;
        obj.profilePicture = doc.data().profilePicture;
    });
    return obj
};
