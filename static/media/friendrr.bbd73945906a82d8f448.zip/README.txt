Final Presentation Video Link: https://youtu.be/8Gzsdqk4x_Q
Andrew Fang - afa41@sfu.ca
Martin Lau - mla335@sfu.ca
Feng Wu - wufengw@sfu.ca
Benjamin Reedel - benjamin_reedel@sfu.ca
Sterling Tamboline - stamboli@sfu.ca
https://findfriendsinc.github.io



For the best experience it is recommended to have at least 2 phones running the app as different users. Alternatively, you can use 1 phone and log in and out between different users

In order for a user to appear on the match list they must have logged into the app within the last 10 days.

User's are able match with people who within an 8 year range (older and younger).

We have provided a list of user's to help reduce the time it takes to register multiple accounts
Email: joey@joey.com         Password: Test12345    Birthdate: 1984-08-08
Email: paul@paul.com         Password: Test12345    Birthdate: 1989-07-12
Email: jessica@jessica.com    Password: Test12345    Birthdate: 1994-05-11
Email: barbie@barbie.com    Password: Test12345    Birthdate: 1992-03-19
Email: test6@test.com       Password: test12345    Birthdate: Aug-08-2022
Email: test7@test.com       Password: test12345        Birthdate: Aug-08-2022
Email: test8@test.com       Password: test12345        Birthdate: Aug-08-2022



References:

Code on implementing chat with firebase adapted from here:
https://www.youtube.com/watch?v=ENK4ONrRm8s