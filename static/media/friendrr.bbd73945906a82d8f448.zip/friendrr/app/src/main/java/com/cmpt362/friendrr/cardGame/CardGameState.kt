package com.cmpt362.friendrr.cardGame

import com.cmpt362.friendrr.cardGame.MemoryCard
import com.cmpt362.friendrr.cardGame.Player

data class CardGameState(var cards: List<MemoryCard>, var currPlayer: Player?, var otherPlayer: Player?,
                         var turn: Int, var gameName: String = "MatchCards") {

    // default no args constructor
    constructor(): this(emptyList(), null, null, 0)
}