package com.cmpt362.friendrr.userAuthentication

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.cmpt362.friendrr.AppPermissions
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.MainActivity
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.cmpt362.friendrr.profileSetup.ProfileOneActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions

class LoginActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var loginButton: Button
    private lateinit var registerButton: Button
    private lateinit var emailInput: EditText
    private lateinit var passwordInput: EditText


    override fun onCreate(savedInstanceState: Bundle?) {
        // Disable night mode
//        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        setTitle(R.string.login)
        loginButton = findViewById(R.id.login_button_id)
        registerButton = findViewById(R.id.login_register_button_id)
        emailInput = findViewById(R.id.login_input_email)
        passwordInput = findViewById(R.id.login_input_password)
        loginButton.setOnClickListener(this)
        registerButton.setOnClickListener(this)
        loginButton.isEnabled = false
        registerButton.isEnabled = false

        AppPermissions.checkPermissions(this)

        //REMOVE THIS WHEN DEPLOYING IN PRODUCTION
        //OR MODIFY WHEN TESTING ON PHYSICAL DEVICE

        if (Build.VERSION.SDK_INT < 29){
            Toast.makeText(this, "Your phone is not supported! You need Android 10 or higher", Toast.LENGTH_LONG).show()
            finish()
        }

        // Check if the user is logged in and has a profile set up
        if (FirebaseAuth.getInstance().currentUser != null) {

            val email = FirebaseAuth.getInstance().currentUser!!.email
            ProfileHelper.setCurrentEmail(this, email.toString())
            val data = hashMapOf(
                "email" to email
            )

            FirebaseFunctions.getInstance()
                .getHttpsCallable("getProfileHasBeenSetup")
                .call(data)
                .addOnSuccessListener {
                    val retObj = it.data as Map<String, *>
                    if (retObj["isProfileSetup"].toString().toBoolean()) {

                        FirebaseFunctions.getInstance()
                            .getHttpsCallable("updateUserLoginDate")
                            .call(data)
                            .addOnSuccessListener {
                                println("success ${it.data}")
                                val intent = Intent(this, MainActivity::class.java)
                                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                intent.putExtra(Constant.UID_KEY, FirebaseAuth.getInstance().currentUser!!.uid)
                                intent.putExtra(Constant.EMAIL_KEY, email)
                                startActivity(intent)
                            }
                            .addOnFailureListener {
                                println("unsuccessful $it")
                            }
                    }else{
                        loginButton.isEnabled = true
                        registerButton.isEnabled = true
                    }
                }
                .addOnFailureListener {
                    println("unsuccessful $it")
                    loginButton.isEnabled = true
                    registerButton.isEnabled = true
                }
        }else{
            loginButton.isEnabled = true
            registerButton.isEnabled = true
        }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.login_button_id -> {
                //handling conditions when users does not enter valid email/password
                if (!AuthHelper.validateEmail(emailInput.text.toString()) ||
                    !AuthHelper.validatePassword(passwordInput.text.toString())) {
                    Toast.makeText(this, "Invalid email or password format", Toast.LENGTH_LONG).show()
                    return
                }
                val email: String = AuthHelper.emailFormatter(emailInput.text.toString())
                val password: String = AuthHelper.passwordFormatter(passwordInput.text.toString())

                //sign in for user
                loginButton.isEnabled = false
                registerButton.isEnabled = false
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(this, "Login Successfully", Toast.LENGTH_LONG).show()
                            lateinit var intent: Intent

                            ProfileHelper.setCurrentEmail(this, emailInput.text.toString())
                            val data = hashMapOf(
                                "email" to email
                            )

                            FirebaseFunctions.getInstance()
                                .getHttpsCallable("getProfileHasBeenSetup")
                                .call(data)
                                .addOnSuccessListener {
                                    val retObj = it.data as Map<String, *>
                                    intent = if (retObj["isProfileSetup"].toString().toBoolean()) {
                                        Intent(this, MainActivity::class.java)

                                    } else {
                                        Intent(this, ProfileOneActivity::class.java)
                                    }
                                    FirebaseFunctions.getInstance()
                                        .getHttpsCallable("updateUserLoginDate")
                                        .call(data)
                                        .addOnSuccessListener {
                                            println("success ${it.data}")
                                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                            intent.putExtra(Constant.UID_KEY, FirebaseAuth.getInstance().currentUser!!.uid)
                                            intent.putExtra(Constant.EMAIL_KEY, email)
                                            startActivity(intent)
                                            //now can retrieve this in anywhere in the app

                                        }
                                        .addOnFailureListener {
                                            println("unsuccessful $it")
                                        }
                                }
                                .addOnFailureListener {
                                    println("unsuccessful $it")
                                    loginButton.isEnabled = true
                                    registerButton.isEnabled = true
                                }
                        } else {
                            println("LOG: " + task.exception)
                            loginButton.isEnabled = true
                            registerButton.isEnabled = true
                            Toast.makeText(this, "Login failed", Toast.LENGTH_LONG).show()
                        }
                    }

            }
            R.id.login_register_button_id -> {
                val intent = Intent(this, RegisterActivity::class.java)
                startActivity(intent)
            }
        }
    }
}