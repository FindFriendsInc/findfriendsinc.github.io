package com.cmpt362.friendrr.friendMatch

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ReplayViewModel:ViewModel() {
    var replay = MutableLiveData<Boolean>()
    var emptyCards = MutableLiveData<Boolean>()

    init {
        replay.value = false
        emptyCards.value = false

    }
}