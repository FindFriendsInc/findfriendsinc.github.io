package com.cmpt362.friendrr.chat

import android.R.attr.left
import android.R.attr.right
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.fragment.app.DialogFragment
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.cardGame.CardGameActivity
import com.cmpt362.friendrr.games.RockPaperScissorActivity
import com.cmpt362.friendrr.photoRoulette.IntroPhotoRouletteActivity


class GameSelectDialog: DialogFragment() {
    companion object {
        const val GAME_DIALOG = 1
        const val DIALOG_KEY = "key"
    }

    private lateinit var receiverEmail: String
    private var isFriend: Boolean = false


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        lateinit var dialog: Dialog
        val bundle = arguments

        if(bundle?.getInt(DIALOG_KEY) == GAME_DIALOG) {
            val view = requireActivity().layoutInflater.inflate(R.layout.fragment_game_select_dialog, null)
            val builder = AlertDialog.Builder(requireActivity())
            builder.setView(view)
            builder.setTitle("Select a Game")

            receiverEmail = bundle?.getString(Constant.KEY_RECEIVER_ID)!!
            isFriend = bundle?.getBoolean(Constant.KEY_FRIEND)!!
            var oppDisplayName = bundle?.getString(Constant.OPP_DISPLAY_NAME)!!

            view.findViewById<CardView>(R.id.cvRock).setOnClickListener{
                var intent = Intent(requireActivity(), RockPaperScissorActivity::class.java)
                intent.putExtra(Constant.KEY_RECEIVER_ID, receiverEmail)
                intent.putExtra(Constant.OPP_DISPLAY_NAME, oppDisplayName)
                startActivity(intent)
                dialog.dismiss()
            }

            if (isFriend) {
                view.findViewById<CardView>(R.id.cvPhoto).setOnClickListener{
                    var intent = Intent(requireActivity(), IntroPhotoRouletteActivity::class.java)
                    intent.putExtra(Constant.KEY_RECEIVER_ID, receiverEmail)
                    intent.putExtra(Constant.OPP_DISPLAY_NAME, oppDisplayName)
                    startActivity(intent)
                    dialog.dismiss()

                }

                view.findViewById<CardView>(R.id.cvCard).setOnClickListener{
                    var intent = Intent(requireActivity(), CardGameActivity::class.java)
                    intent.putExtra(Constant.KEY_RECEIVER_ID, receiverEmail)
                    intent.putExtra(Constant.OPP_DISPLAY_NAME, oppDisplayName)
                    startActivity(intent)
                    dialog.dismiss()

                }

            } else {
                view.findViewById<CardView>(R.id.cvPhoto).setCardBackgroundColor(resources.getColor(R.color.icon_background))
                view.findViewById<CardView>(R.id.cvPhoto).setBackgroundColor(resources.getColor(R.color.icon_background))
                view.findViewById<CardView>(R.id.cvCard).setCardBackgroundColor(resources.getColor(R.color.icon_background))
                view.findViewById<CardView>(R.id.cvCard).setBackgroundColor(resources.getColor(R.color.icon_background))
                view.findViewById<TextView>(R.id.gameSelectText).visibility = View.VISIBLE
            }

            dialog = builder.create()
        }

        return dialog
    }



}