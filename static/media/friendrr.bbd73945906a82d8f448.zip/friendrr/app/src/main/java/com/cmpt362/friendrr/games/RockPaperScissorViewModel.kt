package com.cmpt362.friendrr.games

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class RockPaperScissorViewModel: ViewModel() {

    var rockPaperScissorObj = MutableLiveData<String>()
}