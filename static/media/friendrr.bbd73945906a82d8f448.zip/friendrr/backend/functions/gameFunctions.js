const functions = require("firebase-functions");
const admin = require("firebase-admin");
const firestore = admin.firestore();
if (!admin.apps.length) {
    admin.initializeApp();
}

exports.updateGameState = functions.https.onCall( async (data, context) => {

    //WARNING: updateGameState DOES NOT handle edge cases. All the logic handling must be done on the front-end.
    try{
        const currInfo = await firestore.collection("users").where("email","==",data.currUserEmail).get();
        const otherUserInfo = await firestore.collection("users").where("email","==",data.otherUserEmail).get();
        let currUserGameActivity;
        let otherUserGameActivity;
        currInfo.forEach(doc =>{
            currUserGameActivity = doc.data().gameActivity;
        });
    
        otherUserInfo.forEach(doc =>{
            otherUserGameActivity = doc.data().gameActivity;
        });
    
        currUserGameActivity[data.otherUserEmail] = data.gameState;
        console.log('test omg dude: ', currUserGameActivity)
        let batch1 = firestore.batch();
        currInfo.forEach(doc =>{
            const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
            batch1.update(ref, {
                gameActivity: currUserGameActivity,
            });
            batch1.commit();
        });
    
        otherUserGameActivity[data.currUserEmail] = data.gameState;
        let batch2 = firestore.batch();
        otherUserInfo.forEach(doc =>{
            const ref = admin.firestore()
                .collection('users')
                .doc(doc.id);
            batch2.update(ref, {
                gameActivity: otherUserGameActivity,
            });
            batch2.commit();
        });
        
        return 'success';
    }catch(e) {
        console.log(e);
        return 'error';
    }  
});

exports.getGameState = functions.https.onCall( async (data, context) => {
    const currInfo = await firestore.collection("users").where("email","==",data.currUserEmail).get();
    let currUserGameActivity;

    currInfo.forEach(doc =>{
        currUserGameActivity = doc.data().gameActivity;
    });
    if(Object.keys(currUserGameActivity).length === 0){
        return null
    } else if (currUserGameActivity[data.otherUserEmail]) {
        return currUserGameActivity[data.otherUserEmail]
    } else {
        return null
    }
});

exports.deleteGameState = functions.https.onCall( async (data, context) => {
    //WARNING: Only validation is to check if the key-value exists
    // provide currUserEmail,otherUserEmail,gameType, winning email, losing email
    try{
        const currInfo = await firestore.collection("users").where("email","==",data.currUserEmail).get();
        const otherUserInfo = await firestore.collection("users").where("email","==",data.otherUserEmail).get();
        if(data.winEmail && data.loseEmail && data.gameType){//optional winlose(or total games played depending on game) game recording
            console.log('recording user winlose/gamesplayed data');
            let recordBatch1 = firestore.batch();
            if(data.gameType === "photoGame") { //only records total games played
                let currentUserGamesPlayed;
                currInfo.forEach(doc =>{
                    currentUserGamesPlayed = doc.data().cameraTotalGamesPlayed;
                    currentUserGamesPlayed += 1;
                    const ref1 = admin.firestore()
                        .collection('users')
                        .doc(doc.id);
                    recordBatch1.update(ref1, {
                        cameraTotalGamesPlayed: currentUserGamesPlayed,
                    });
                    recordBatch1.commit();
                });
                
                let recordBatch2 = firestore.batch();
                let otherUserGamesPlayed;
                otherUserInfo.forEach(doc =>{
                    otherUserGamesPlayed = doc.data().cameraTotalGamesPlayed;
                    otherUserGamesPlayed += 1;
                    const ref2 = admin.firestore()
                        .collection('users')
                        .doc(doc.id);
                    recordBatch2.update(ref2, {
                        cameraTotalGamesPlayed: otherUserGamesPlayed,
                    });
                    recordBatch2.commit();
                });
                
            }else{
                let currUserWin;
                let currUserLose;
                let otherUserWin;
                let otherUserLose;
                if (data.gameType === "RPS"){ //records winlose
                    let recordBatch1 = firestore.batch();
                    currInfo.forEach(doc =>{
                        currUserWin = doc.data().rpsWin;
                        currUserLose = doc.data().rpsLose;
                        if(data.winEmail === data.currUserEmail){
                            currUserWin += 1;
                        }else{
                            currUserLose += 1;
                        }
                        const ref1 = admin.firestore()
                            .collection('users')
                            .doc(doc.id);
                        recordBatch1.update(ref1, {
                            rpsWin: currUserWin,
                            rpsLose: currUserLose,
                        });
                        recordBatch1.commit();
                    });

                    let recordBatch2 = firestore.batch();
                    otherUserInfo.forEach(doc => {
                        otherUserWin = doc.data().rpsWin;
                        otherUserLose = doc.data().rpsLose;
                        if(data.winEmail === data.currUserEmail) {
                            otherUserLose += 1;
                        }else{
                            otherUserWin += 1;
                        }
                        const ref2 = admin.firestore()
                            .collection('users')
                            .doc(doc.id);
                        recordBatch2.update(ref2, {
                            rpsWin: otherUserWin,
                            rpsLose: otherUserLose,
                        });
                        recordBatch2.commit();
                    });                    
                }else if(data.gameType === "cardMatch"){
                    let recordBatch1 = firestore.batch();
                    currInfo.forEach(doc =>{
                        currUserWin = doc.data().cardWin;
                        currUserLose = doc.data().cardLose;
                        if(data.winEmail === data.currUserEmail){
                            currUserWin += 1;
                        }else{
                            currUserLose += 1;
                        }
                        const ref1 = admin.firestore()
                            .collection('users')
                            .doc(doc.id);
                        recordBatch1.update(ref1, {
                            cardWin: currUserWin,
                            cardLose: currUserLose,
                        });
                        recordBatch1.commit();
                    });

                    let recordBatch2 = firestore.batch();
                    otherUserInfo.forEach(doc => {
                        otherUserWin = doc.data().cardWin;
                        otherUserLose = doc.data().cardLose;
                        if(data.winEmail === data.currUserEmail) {
                            otherUserLose += 1;
                        }else{
                            otherUserWin += 1;
                        }
                        const ref2 = admin.firestore()
                            .collection('users')
                            .doc(doc.id);
                        recordBatch2.update(ref2, {
                            cardWin: otherUserWin,
                            cardLose: otherUserLose,
                        });
                        recordBatch2.commit();
                    });       
                }
            }
            
        }

        let currUserGameActivity;
        let otherUserGameActivity;
        currInfo.forEach(doc =>{
            currUserGameActivity = doc.data().gameActivity;
        });
    
        otherUserInfo.forEach(doc =>{
            otherUserGameActivity = doc.data().gameActivity;
        });
    
        if(currUserGameActivity[data.otherUserEmail] !== undefined){
            // currUserGameActivity[data.otherUserEmail] = data.gameState;
            delete currUserGameActivity[data.otherUserEmail]
            let batch1 = firestore.batch();
            currInfo.forEach(doc =>{
                const ref = admin.firestore()
                    .collection('users')
                    .doc(doc.id);
                batch1.update(ref, {
                    gameActivity: currUserGameActivity,
                });
                batch1.commit();
            });
        }else {
            return "error, no gamestate to delete current user"
        }
        
        if(otherUserGameActivity[data.currUserEmail] != undefined){
            delete otherUserGameActivity[data.currUserEmail]
            // otherUserGameActivity[data.currUserEmail] = data.gameState;
            let batch2 = firestore.batch();
            otherUserInfo.forEach(doc =>{
                const ref = admin.firestore()
                    .collection('users')
                    .doc(doc.id);
                batch2.update(ref, {
                    gameActivity: otherUserGameActivity,
                });
                batch2.commit();
            });
        }else {
            return "error, no gamestate to delete on otherUser"
        }
        return 'success';
    }catch(e) {
        console.log(e);
        return 'error';
    }  
});
