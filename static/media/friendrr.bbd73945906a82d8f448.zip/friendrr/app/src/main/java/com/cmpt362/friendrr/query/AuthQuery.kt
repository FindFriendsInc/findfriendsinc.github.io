package com.cmpt362.friendrr.query

import com.google.firebase.functions.FirebaseFunctions
import java.lang.Exception

object AuthQuery {
    suspend fun getProfileInfo(email: String): Any {
        
        val data = HashMap<String, Any>()
        lateinit var retObj: Any
        data["email"] = email
            return try {
               FirebaseFunctions.getInstance()
                   .getHttpsCallable("getProfile")
                   .call(data)
                   .addOnFailureListener {
                       println("gg yo $it")
                   }
                   .addOnSuccessListener {
                       println("success yo ${it.data}")
    //                   return it.data
                       it.data!!
                   }
           }catch(e: Exception) {
               println(e)
           }
        }
}