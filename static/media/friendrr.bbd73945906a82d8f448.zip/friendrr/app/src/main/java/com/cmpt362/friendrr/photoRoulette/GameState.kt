package com.cmpt362.friendrr.photoRoulette

class GameState(turnEmail: String, currentPhoto: String, currentGuessWord: String
    ,currentRound: Int, initial: Boolean, gameName: String) {
    var turnEmail: String
    var currentPhoto: String
    var currentGuessWord: String
    var gameName: String
    var currentRound: Int
    var initial: Boolean
    init {
        this.turnEmail = turnEmail
        this.currentPhoto = currentPhoto
        this.currentGuessWord = currentGuessWord
        this.currentRound = currentRound
        this.initial = initial
        this.gameName = gameName

    }

}