package com.cmpt362.friendrr.cardGame

import com.cmpt362.friendrr.R

data class MemoryCard(var image: Int, var position: Int, var claimed: String, var isFaceUp: Boolean = false
    ) {

    constructor(): this(
        R.drawable.ic_magnifying_glass_svgrepo_com,
        0, "empty", false)
}
