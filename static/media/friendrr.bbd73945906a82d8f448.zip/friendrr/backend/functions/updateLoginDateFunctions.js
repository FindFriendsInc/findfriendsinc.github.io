const functions = require("firebase-functions");
// The Firebase Admin SDK to access Cloud Firestore
const admin = require("firebase-admin");

const firestore = admin.firestore();
if (!admin.apps.length) {
    admin.initializeApp();
}

// adds basic attribute to the database
exports.updateLoginDate = functions.https.onCall( async (data, context) => {
    const datetime = new Date();
    const snapshot = await firestore.collection("users").where("email", "==", data.email).get();
    let obj = {};
    let batch = firestore.batch();
    snapshot.forEach(doc => {
        const ref = admin.firestore()
        .collection('users')  //You need to identify the collection
        .doc(doc.id);
        batch.update(ref, {lastLoggedInDate: datetime.toISOString().slice(0,10)});
    });
       
    batch.commit();
    
    return obj;
});
