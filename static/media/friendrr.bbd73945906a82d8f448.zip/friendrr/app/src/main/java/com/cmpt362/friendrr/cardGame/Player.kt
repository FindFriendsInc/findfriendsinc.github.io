package com.cmpt362.friendrr.cardGame

data class Player(var name: String?,
                  var email: String?,
                  var theirTurn: Boolean = false,
                  var score: Int = 0)