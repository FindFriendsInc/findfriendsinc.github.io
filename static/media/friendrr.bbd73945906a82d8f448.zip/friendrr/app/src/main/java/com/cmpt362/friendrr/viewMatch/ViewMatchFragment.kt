package com.cmpt362.friendrr.viewMatch

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.GlobalViewModel
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.addFriend.AddFriendActivity
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.GsonBuilder

class ViewMatchFragment: Fragment() {
    private lateinit var arrayAdapter: NotificationListAdapter
    private lateinit var arrayList: ArrayList<MatchUser>
    private lateinit var myListView: ListView
    private lateinit var progressBar: ProgressBar
    private lateinit var errorText: TextView
    private lateinit var globalViewModel: GlobalViewModel

    override fun onCreateView(inflater: LayoutInflater, viewGroup: ViewGroup?, bundle: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_view_match, viewGroup, false)
        progressBar = view.findViewById(R.id.recentMatchesProgressBar)
        myListView = view.findViewById(R.id.view_match_history_list)
        globalViewModel = ViewModelProvider(requireActivity()).get(GlobalViewModel::class.java)
        
        val data = HashMap<String, Any>()
        data["email"] = ProfileHelper.getCurrentEmail(requireActivity())

        globalViewModel.setLoadingStatus(true)
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getCandidateAndFriendList")
            .call(data)
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                arrayList = ArrayList()
                val retList = it.data as ArrayList<Map<String, *>>

                if (retList.isEmpty()) {
                    errorText = view.findViewById(R.id.recentMatchesError)
                    errorText.text = "You haven't made any matches yet!"
                    errorText.visibility  = View.VISIBLE
                } else {
                    for (obj in retList) {
                        val newUser = MatchUser(
                            obj["email"].toString(), obj["displayName"].toString(),
                            obj["profilePicture"].toString(), obj["relationType"].toString()
                        )
                        arrayList.add(newUser)

                    }
                    arrayAdapter = NotificationListAdapter(requireActivity(), arrayList)
                    myListView.adapter = arrayAdapter
                    myListView.visibility = View.VISIBLE
                }
                globalViewModel.setLoadingStatus(false)
            }
            .addOnFailureListener {
                progressBar.visibility = View.GONE
                println("unsuccessful $it")
                errorText = view.findViewById(R.id.recentMatchesError)
                errorText.text = "Error in finding friends"
                errorText.visibility  = View.VISIBLE
                globalViewModel.setLoadingStatus(false)
            }

        myListView.setOnItemClickListener{ parent, view, position, id ->
            var intent = Intent(activity, AddFriendActivity::class.java)
            intent.putExtra(Constant.EMAIL_KEY, ProfileHelper.getCurrentEmail(requireActivity()))
            val userObj: MatchUser = arrayAdapter.getItem(position) as MatchUser
            intent.putExtra(Constant.OTHER_USER_EMAIL_KEY, userObj.getEmail())
            intent.putExtra(Constant.OTHER_USER_DISPLAY_NAME_KEY, userObj.getDisplayName())
            ViewMatchHelper.storeProfilePicToLocalCache(requireActivity(), userObj.getProfilePicture())
            intent.putExtra(Constant.RELATIONSHIP_TYPE, userObj.getRelationType())
            startActivity(intent)
        }
        return view
    }

    override fun onResume() {
        super.onResume()
        val data = HashMap<String, Any>()
        data["email"] = ProfileHelper.getCurrentEmail(requireActivity())
        globalViewModel.setLoadingStatus(true)
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getCandidateAndFriendList")
            .call(data)
            .addOnSuccessListener {
                arrayList = ArrayList()
                val retList = it.data as ArrayList<Map<String, *>>
                for(obj in retList) {
                    val newUser = MatchUser(obj["email"].toString(), obj["displayName"].toString(),
                        obj["profilePicture"].toString(), obj["relationType"].toString())
                    arrayList.add(newUser)

                }
                arrayAdapter = NotificationListAdapter(requireActivity(), arrayList)
                myListView.adapter = arrayAdapter
                globalViewModel.setLoadingStatus(false)
            }
            .addOnFailureListener {
                println("unsuccessful $it")
                globalViewModel.setLoadingStatus(false)
            }
    }
}