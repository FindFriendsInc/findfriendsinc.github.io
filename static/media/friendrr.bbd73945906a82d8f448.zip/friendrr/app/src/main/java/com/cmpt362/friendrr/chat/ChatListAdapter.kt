package com.cmpt362.friendrr.chat

import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlin.collections.ArrayList

class ChatListAdapter (val context: Context, val users: ArrayList<Map<String, *>>): BaseAdapter() {

    override fun getCount(): Int {
        return users.size
    }

    override fun getItem(position: Int): Map<String, *>{
        return users[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, view: View?, parent: ViewGroup?): View {
        val retView: View = View.inflate(context, R.layout.layout_adapter_chat_list, null)


        val nameText = retView?.findViewById<TextView>(R.id.listTextName)
        val lastMessageText = retView?.findViewById<TextView>(R.id.listLastMessageText)
        val profileImage = retView?.findViewById<ImageView>(R.id.listImageProfile)


        nameText?.text = users[position]["displayName"].toString()

        if (users[position]["relationType"].toString() == "friend") {
            retView?.findViewById<androidx.constraintlayout.widget.ConstraintLayout>(R.id.chatListItemContainer)!!
                .setBackgroundColor(ContextCompat.getColor(context, R.color.friend_background))
        }


        var database = FirebaseFirestore.getInstance()
        var currentUserEmail = ProfileHelper.getCurrentEmail(context as Activity)

        var query1: QuerySnapshot
        var query2: QuerySnapshot
        database.collection(Constant.KEY_COLLECTION_CHAT)
            .whereEqualTo(Constant.KEY_SENDER_ID, currentUserEmail)
            .whereEqualTo(Constant.KEY_RECEIVER_ID, users[position]["email"].toString())
            .limit(1)
            .get()
            .addOnSuccessListener { result ->
                query1 = result

                database.collection(Constant.KEY_COLLECTION_CHAT)
                    .whereEqualTo(Constant.KEY_SENDER_ID, users[position]["email"].toString())
                    .whereEqualTo(Constant.KEY_RECEIVER_ID, currentUserEmail)
                    .limit(1)
                    .get()
                    .addOnSuccessListener { result ->
                        query2 = result

                        if (query1.documents.size > 0 && query2.documents.size > 0) {
                            if (query1.documents[0].data!!["timestamp"] as Timestamp > query2.documents[0].data!!["timestamp"] as Timestamp) {
                                var message = query1.documents[0].data!!["message"]
                                lastMessageText?.text = message.toString()
                            } else if (query2.documents[0].data!!["timestamp"] as Timestamp > query1.documents[0].data!!["timestamp"] as Timestamp) {
                                var message = query2.documents[0].data!!["message"]
                                lastMessageText?.text = message.toString()
                            }
                        } else if (query1.documents.size > 0) {
                            var message = query1.documents[0].data!!["message"]
                            lastMessageText?.text = message.toString()
                        } else if (query2.documents.size > 0) {
                            var message = query2.documents[0].data!!["message"]
                            lastMessageText?.text = message.toString()
                        }
                    }
            }

        //set profile picture
        val imageAsBytes = Base64.decode(users[position]["profilePicture"].toString().toByteArray(), Base64.DEFAULT)
        profileImage?.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size))

        return retView!!
    }
}

