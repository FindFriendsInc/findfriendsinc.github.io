package com.cmpt362.friendrr.chat

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.lifecycle.ViewModelProvider
import com.cmpt362.friendrr.GlobalViewModel
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.friendMatch.SwipeAdapter
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.functions.FirebaseFunctions


class ChatListFragment : Fragment() {
    private var email  = ""
    private lateinit var adapter: ChatListAdapter
    private lateinit var myListView: ListView
    private lateinit var errorText: TextView
    private lateinit var friends: ArrayList<Map<String, *>>
    private lateinit var progressBar: ProgressBar
    private lateinit var globalViewModel: GlobalViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val retView =  inflater.inflate(R.layout.fragment_chat_list, container, false)
        myListView = retView.findViewById(R.id.listChatFriends)
        progressBar = retView.findViewById(R.id.chatListProgressBar)
        globalViewModel = ViewModelProvider(requireActivity()).get(GlobalViewModel::class.java)
        

        email = ProfileHelper.getCurrentEmail(context as Activity)
        val data = hashMapOf(
            "email" to email
        )

        globalViewModel.setLoadingStatus(true)
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getCandidateAndFriendList")
            .call(data)
            .addOnSuccessListener {
                progressBar.visibility = View.GONE
                friends = it.data as ArrayList<Map<String, *>>
                adapter = ChatListAdapter(requireActivity(), friends)
                println("successful $it")
                myListView.adapter = adapter
                myListView.visibility = View.VISIBLE

                if (friends.isEmpty()) {
                    errorText = retView.findViewById(R.id.chatListError)
                    errorText.text = "You haven't made any matches yet!"
                    errorText.visibility  = View.VISIBLE
                } else {
                    myListView.setOnItemClickListener() { parent: AdapterView<*>, textView: View, position: Int, id: Long ->
                        var friend : Map<String, *> = friends[position]
                        val email = friend["email"]
                        println("debug: tapped on: $email")

                        val intent = Intent(requireActivity(), ChatActivity::class.java)
                        intent.putExtra("RECEIVER_EMAIL", email.toString())
                        startActivity(intent)

                    }
                }
                globalViewModel.setLoadingStatus(false)
            }
            .addOnFailureListener {
                println("unsuccessful $it")
                progressBar.visibility = View.GONE
                errorText = retView.findViewById(R.id.chatListError)
                errorText.text = "Error in finding friends"
                errorText.visibility  = View.VISIBLE
                globalViewModel.setLoadingStatus(false)
            }

        return retView
    }

}