package com.cmpt362.friendrr.photoRoulette

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Picture
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.cmpt362.friendrr.profileSetup.ProfileThreeActivity
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.GsonBuilder
import java.io.File

class PictureActivity: AppCompatActivity(), View.OnClickListener{
    lateinit var cameraResult: ActivityResultLauncher<Intent>
    var isPictureTaken = false
    lateinit var takePictureButton: Button
    lateinit var endTurnButton: Button
    lateinit var tempImgUri: Uri
    lateinit var imgView: ImageView
    private val fileName: String = "cameragame_tempfile"
    lateinit var currentGameState: GameState
    lateinit var randomWordTextView: TextView
    lateinit var otherUserEmail: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        otherUserEmail = intent.getStringExtra(Constant.OTHER_USER_EMAIL_KEY).toString()
        setContentView(R.layout.activity_take_picture)
        takePictureButton = findViewById(R.id.take_picture)
        endTurnButton = findViewById(R.id.end_turn)
        randomWordTextView = findViewById(R.id.random_word)
        takePictureButton.setOnClickListener(this)
        endTurnButton.setOnClickListener(this)
        imgView = findViewById(R.id.profile_image)

        if(intent.getStringExtra("GAME_TYPE_KEY") == GameConstants.EXISTING_GAME){
            currentGameState = GameState("", "", GameHelper.getRandomWord(), intent.getIntExtra(GameConstants.ROUNDS_KEY,1) + 1, false, "SnapThis")
        }else if(intent.getStringExtra("GAME_TYPE_KEY") == GameConstants.NEW_GAME){
            currentGameState = GameState("", "", GameHelper.getRandomWord(), 1, true, "SnapThis")
        }
        randomWordTextView.text = "Round ${currentGameState.currentRound}: ${currentGameState.currentGuessWord}"

        if(!isPictureTaken) {
            endTurnButton.isEnabled = false
        }

        //camera setup
        val tempImgFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), fileName)
        tempImgUri = FileProvider.getUriForFile(this, "com.cmpt362.friendrr", tempImgFile)
        cameraResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult())
        { result: ActivityResult ->
            if(result.resultCode == Activity.RESULT_OK){
                var bitmap = ProfileHelper.getBitmapHelper(this, tempImgUri)
                bitmap = Bitmap.createScaledBitmap(bitmap,100,100, true)
                imgView.setImageBitmap(bitmap)

                val encoded: String = ProfileHelper.encodeBitmapHelper(bitmap)
                if(encoded != null){
                    currentGameState.currentPhoto = encoded!!
                    endTurnButton.isEnabled = true
                }
            }
        }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.take_picture -> {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                intent.putExtra(
                    MediaStore.EXTRA_OUTPUT,
                    this.tempImgUri
                )
                this.cameraResult.launch(intent)
            }
            R.id.end_turn -> {
                endTurnButton.isEnabled = false
                currentGameState.turnEmail = otherUserEmail
                val data = HashMap<String, Any>()
                val gson = GsonBuilder().create()
                val jsonObj = gson.toJson(currentGameState)
                data["currUserEmail"] = ProfileHelper.getCurrentEmail(this)
                data["otherUserEmail"] = otherUserEmail
                data["gameState"] = jsonObj
                FirebaseFunctions.getInstance()
                    .getHttpsCallable("updateGameState")
                    .call(data)
                    .addOnSuccessListener {
                        println("updateGameState success  ${it.data}")
                        finish()
                    }
                    .addOnFailureListener {
                        println("unsuccessful $it")
                    }
            }
        }
    }
}