package com.cmpt362.friendrr.profileSetup

import android.R.attr.path
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaPlayer
import android.net.Uri
import android.util.Base64
import android.widget.ImageView
import androidx.core.graphics.drawable.toBitmap
import com.cmpt362.friendrr.Constant
import org.apache.commons.io.FileUtils
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream


object ProfileHelper {
    fun addCurrentProfileToLocalStorage(activity: Activity, key: String, value: Any) {
        if (key == Constant.SELECTED_HOBBIES_LIST) {
            val sharedPref: SharedPreferences = activity.getSharedPreferences("profileSetup",
                Context.MODE_PRIVATE)
            with (sharedPref.edit()) {
                putStringSet(key, value as Set<String>)
                apply()
            }
        } else {
            val sharedPref: SharedPreferences = activity.getSharedPreferences("profileSetup",
                Context.MODE_PRIVATE)
            with (sharedPref.edit()) {
                putString(key, value.toString())
                apply()
            }
        }
    }
    fun clearCurrentProfileFromLocalStorage(activity: Activity) {
        val emptySet = setOf<String>()
        val sharedPref: SharedPreferences = activity.getSharedPreferences("profileSetup",
            Context.MODE_PRIVATE)
        with (sharedPref.edit()) {
            putStringSet(Constant.SELECTED_HOBBIES_LIST, emptySet)
            putString(Constant.DISPLAY_NAME_KEY, "")
            putString(Constant.BIRTHDATE_KEY, "")
            putString(Constant.GENDER_KEY, "")
            putString(Constant.PROFILE_PIC_KEY, "")
            putString(Constant.BYTE_ARRAY_KEY, "")
            apply()
        }
    }
    fun setCurrentEmail(activity: Activity, value: Any) {
        val sharedPref: SharedPreferences = activity.getSharedPreferences("tempLoginInfo",
            Context.MODE_PRIVATE)
        with (sharedPref.edit()) {
            putString(Constant.EMAIL_KEY, value.toString())
            apply()
        }
    }
    fun getCurrentEmail(activity: Activity): String {
        val sharedPref: SharedPreferences = activity.getSharedPreferences("tempLoginInfo",
            Context.MODE_PRIVATE)
        return sharedPref.getString(Constant.EMAIL_KEY, "")!!
    }
    fun encodeBitmapHelper(bitmap: Bitmap): String {
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        val bArr: ByteArray = baos.toByteArray()
        return Base64.encodeToString(bArr, Base64.DEFAULT)
    }

    fun imageViewToBitMapHelper(imgView: ImageView): Bitmap? {
        imgView.invalidate()
        val drawable = imgView.drawable
        try{
            return drawable.toBitmap()
        }catch(e: Exception){
            return null
        }
    }

    /*
    * Citation: getBitmapHelper function is derived from week two lecture project(CameraDemoKotlin.zip)
    * */
    fun getBitmapHelper(context: Context, imgUri: Uri): Bitmap {
        var bitmap = BitmapFactory.decodeStream(context.contentResolver.openInputStream(imgUri))
        val matrix = Matrix()
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    fun convertMp3toByteArrayString(context: Context, file: File): String {
        val bytes = FileUtils.readFileToByteArray(file)
        val encoded = Base64.encodeToString(bytes, 0)
//        val decoded = Base64.decode(encoded, 0)
        return encoded
    }

    //dervied from: https://stackoverflow.com/questions/10908552/play-byte-array-in-mediaplayer-android
    fun playMp3(activity: Activity, soundByteArray: ByteArray, file: File): MediaPlayer{
        val newFile = File(activity.getExternalFilesDir(null), "temp_audio.mp3")
        val fos = FileOutputStream(newFile)
        fos.write(soundByteArray)
        fos.close()
        val mediaPlayer = MediaPlayer()
        val fis = FileInputStream(newFile)
        mediaPlayer.setDataSource(newFile.toString())
        mediaPlayer.prepare()
        mediaPlayer.start()
        return mediaPlayer
    }
}