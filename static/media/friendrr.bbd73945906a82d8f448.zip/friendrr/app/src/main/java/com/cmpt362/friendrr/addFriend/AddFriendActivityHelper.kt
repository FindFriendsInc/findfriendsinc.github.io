package com.cmpt362.friendrr.addFriend

object AddFriendActivityHelper {
}