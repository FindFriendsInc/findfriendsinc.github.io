package com.cmpt362.friendrr.photoRoulette

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.addFriend.AddFriendActivity
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.google.firebase.functions.FirebaseFunctions
import com.google.gson.GsonBuilder

class IntroPhotoRouletteActivity: AppCompatActivity(), View.OnClickListener {
    lateinit var startButton: Button
    private lateinit var otherUserEmail: String
    val TEST_USER = "test100@test.com"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val data = HashMap<String, Any>()
        //this is hard coded for now

        otherUserEmail = intent.getStringExtra(Constant.KEY_RECEIVER_ID) as String

        data["currUserEmail"] = ProfileHelper.getCurrentEmail(this)
        data["otherUserEmail"] = otherUserEmail
        
        val test = ProfileHelper.getCurrentEmail(this)
        val test2 = otherUserEmail
        FirebaseFunctions.getInstance()
            .getHttpsCallable("getGameState")
            .call(data)
            .addOnSuccessListener {
                println("getGameState success  ${it.data}")
                val retStr = it.data
                if(retStr == null){
                    setContentView(R.layout.activity_intro_photoroulette)
                    startButton = findViewById(R.id.photo_game_start_button)
                    startButton.setOnClickListener(this)
                }else{
                    //create new either open guess_activity first
                    val gson = GsonBuilder().create()
                    val retObj = gson.fromJson(retStr as String, GameState::class.java)
                    if(retObj.turnEmail != ProfileHelper.getCurrentEmail(this)) {
                        val intent = Intent(this, WaitTurnActivity::class.java)
                        startActivity(intent)
                    }else{
                        val intent = Intent(this, GuessActivity::class.java)
                        intent.putExtra(Constant.OTHER_USER_EMAIL_KEY, otherUserEmail)
                        intent.putExtra( "GAME_TYPE_KEY", GameConstants.EXISTING_GAME)
                        startActivity(intent)
                    }
                }
            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.photo_game_start_button -> {
                val intent = Intent(this, PictureActivity::class.java)
                intent.putExtra( "GAME_TYPE_KEY", GameConstants.NEW_GAME)
                intent.putExtra(Constant.OTHER_USER_EMAIL_KEY, otherUserEmail)
                startActivity(intent)
            }
        }
    }
}