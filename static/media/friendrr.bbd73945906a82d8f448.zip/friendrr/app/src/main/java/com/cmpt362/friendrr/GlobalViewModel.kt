package com.cmpt362.friendrr

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class GlobalViewModel: ViewModel() {
    var isLoading = MutableLiveData<Boolean>()

    init{
        isLoading.value = false
    }

    fun getLoadingStatus(): Boolean {
        return isLoading.value!!
    }

    fun setLoadingStatus(boolVal: Boolean){
        isLoading.value = boolVal
    }
}