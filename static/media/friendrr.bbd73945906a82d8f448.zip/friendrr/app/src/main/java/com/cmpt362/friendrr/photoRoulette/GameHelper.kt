package com.cmpt362.friendrr.photoRoulette

object GameHelper {
    fun getRandomWord(): String {
        val randomList = GameConstants.guessWords
        val randomIndex = (0..(randomList.size-1)).random()
        return randomList[randomIndex]
    }
    fun randomizedString(str: String): String {
        val list = ArrayList<Char>()
        var retStr = ""
        for(char in str){
            list.add(char)
        }
        list.shuffle()
        for(char in list){
            retStr += "$char "
        }
        return retStr
    }
}