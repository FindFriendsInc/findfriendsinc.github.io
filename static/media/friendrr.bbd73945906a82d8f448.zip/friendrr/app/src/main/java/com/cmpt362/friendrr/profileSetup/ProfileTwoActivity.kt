package com.cmpt362.friendrr.profileSetup

import android.content.Intent
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Environment
import android.util.Base64
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import java.io.File


class ProfileTwoActivity : AppCompatActivity() {

    private lateinit var profile_msg: TextView
    private lateinit var nextBtn: Button
    private lateinit var startRecordingBtn: Button
    private lateinit var replayRecordingBtn: Button
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var mediaRecorder: MediaRecorder
    private lateinit var filepath: File
    private lateinit var recordedByteArr: ByteArray
    private var isRecordingSet = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_two)

        val username = intent.getStringExtra("username")
        val message = "Almost there $username. Let's hear your voice. Give a quick 5 second introduction about yourself! It can be anything"

        profile_msg = findViewById(R.id.profile_msg)
        profile_msg.text = message

        startRecordingBtn = findViewById(R.id.start_recording)
        replayRecordingBtn = findViewById(R.id.replay_recording)
        nextBtn = findViewById(R.id.next_btn)

        startRecordingBtn.setOnClickListener {

            // Reset isRecordingSet so that the user cannot replay a recording while a recording is in progress
            isRecordingSet = false

            // Disable record, replay and next buttons while a recording is in progress
            disableRecordButton()
            disableReplayButton()
            disableNextButton()

            filepath = File(getExternalFilesDir(null), "friendrr_audio_recording.mp3")
            mediaRecorder = MediaRecorder()
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mediaRecorder.setOutputFile(filepath.toString())

            // Record for 5 seconds
            mediaRecorder.prepare()
            mediaRecorder.start()
            object : CountDownTimer(5000, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    // Show progress bar here or seconds remaining
                }

                // After 5 seconds stop the recording and show a toast to user
                override fun onFinish() {
                    mediaRecorder.stop()
                    mediaRecorder.reset()
                    mediaRecorder.release()
                    Toast.makeText(applicationContext, "Recording complete", Toast.LENGTH_LONG).show()
                    isRecordingSet = true
                    // Enable the record, replay and next buttons when the recording is finished
                    enableRecordButton()
                    enableReplayButton()
                    enableNextButton()
                }
            }.start()
        }

        // Replay button only works if a recording has been set
        replayRecordingBtn.setOnClickListener {
            if (isRecordingSet) {
                // Disable record, replay and next buttons while a recording is playing
                disableRecordButton()
                disableReplayButton()
                disableNextButton()

                // TODO: Verify the audio recording works and save it
                val encode = ProfileHelper.convertMp3toByteArrayString(this, filepath)
                recordedByteArr = Base64.decode(encode, 0)
                ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.BYTE_ARRAY_KEY, encode)

                mediaPlayer = ProfileHelper.playMp3(this, recordedByteArr, filepath)
                mediaPlayer.setOnCompletionListener {
                    //Enable the record, replay and next buttons when the recording is finished
                    enableRecordButton()
                    enableReplayButton()
                    enableNextButton()
                }

            }
        }

        nextBtn.setOnClickListener {
            // Pass information and save it all on the final profile step
            val intent = Intent(this, ProfileThreeActivity::class.java)
            startActivity(intent)
        }

        // Disable next and replay buttons until a recording is set and after the setOnClickListeners
        disableReplayButton()
        disableNextButton()
    }

    private fun disableNextButton() {
        nextBtn.alpha = 0.6f
        nextBtn.isClickable = false
    }

    private fun enableNextButton() {
        nextBtn.alpha = 1f
        nextBtn.isClickable = true
    }

    private fun disableRecordButton() {
        startRecordingBtn.alpha = 0.6f
        startRecordingBtn.isClickable = false
    }

    private fun enableRecordButton() {
        startRecordingBtn.alpha = 1f
        startRecordingBtn.isClickable = true
    }

    private fun disableReplayButton() {
        replayRecordingBtn.alpha = 0.6f
        replayRecordingBtn.isClickable = false
    }

    private fun enableReplayButton() {
        replayRecordingBtn.alpha = 1f
        replayRecordingBtn.isClickable = true
    }
}