package com.cmpt362.friendrr.addFriend

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.MainActivity
import com.cmpt362.friendrr.R
import com.cmpt362.friendrr.profileSetup.ProfileHelper
import com.cmpt362.friendrr.viewMatch.ViewMatchHelper
import com.google.firebase.functions.FirebaseFunctions

class AddFriendActivity: AppCompatActivity() {
    private lateinit var addFriendText: TextView
    private lateinit var currentUserEmail: String
    private lateinit var otherUserEmail: String
    private lateinit var relationshipType: String
    private lateinit var otherUserDisplayName: String
    private lateinit var imgView: ImageView
    private lateinit var addFriendYesButton: Button
    private lateinit var addFriendNoButton: Button
    private lateinit var removeFriendButton: Button
    private lateinit var removeFriendCancelButton: Button
    private lateinit var removeMatchButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friend_add)
        addFriendText = findViewById(R.id.add_friend_text)
        imgView = findViewById(R.id.add_friend_pic)
        addFriendYesButton = findViewById(R.id.add_friend_yes_button)
        addFriendNoButton = findViewById(R.id.add_friend_no_button)
        removeFriendButton = findViewById(R.id.remove_friend_remove_button)
        removeFriendCancelButton = findViewById(R.id.remove_friend_cancel_button)
        removeMatchButton = findViewById(R.id.remove_match)

        val profilePicByteString = ViewMatchHelper.getProfilePicFromLocalCache(this)
        currentUserEmail = intent.getStringExtra(Constant.EMAIL_KEY).toString()
        otherUserEmail = intent.getStringExtra(Constant.OTHER_USER_EMAIL_KEY).toString()
        otherUserDisplayName = intent.getStringExtra(Constant.OTHER_USER_DISPLAY_NAME_KEY).toString()
        relationshipType = intent.getStringExtra(Constant.RELATIONSHIP_TYPE).toString()

        if(relationshipType == "friendCandidate"){
            removeFriendButton.visibility = View.GONE
            removeFriendCancelButton.visibility = View.GONE
            addFriendText.text = "Do you want to be friends with $otherUserDisplayName"

        }else if(relationshipType ==  "friend") {
            addFriendYesButton.visibility = View.GONE
            addFriendNoButton.visibility = View.GONE
            removeMatchButton.visibility = View.GONE
            addFriendText.text = "Do you want to remove $otherUserEmail as your friend?"
        }
        val imageAsBytes = Base64.decode(profilePicByteString.toByteArray(), Base64.DEFAULT)
        imgView.setImageBitmap(BitmapFactory.decodeByteArray(imageAsBytes, 0, imageAsBytes.size))
    }

    fun onYesClicked(view: View) {
        val data = HashMap<String, Any>()
        data["email"] = currentUserEmail
        data["otherUserEmail"] = otherUserEmail
        addFriendYesButton.isEnabled = false
        addFriendNoButton.isEnabled = false
        removeMatchButton.isEnabled = false
        
        FirebaseFunctions.getInstance()
            .getHttpsCallable("friendRequest")
            .call(data)
            .addOnSuccessListener {
                println("getCandidateAndFriendList success  ${it.data}")
                finish()

            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }

    fun onNoClicked(view: View) {
        if(view.id == R.id.add_friend_no_button) {
            finish()
            Toast.makeText(this, "Aww, you didn't get along?", Toast.LENGTH_LONG).show()
        }
    }

    fun handleRemoveFriendConfirmed(view: View){
        val data = HashMap<String, Any>()
        data["email"] = currentUserEmail
        data["otherUserEmail"] = otherUserEmail
        removeFriendButton.isEnabled = false
        removeFriendCancelButton.isEnabled = false
        
        FirebaseFunctions.getInstance()
            .getHttpsCallable("removeFriend")
            .call(data)
            .addOnSuccessListener {
                Toast.makeText(this, "$otherUserDisplayName is no longer your friend", Toast.LENGTH_LONG).show()
                finish()

            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }

    fun handleRemoveMatch(view: View){
        val data = HashMap<String, Any>()
        data["email"] = currentUserEmail
        data["otherUserEmail"] = otherUserEmail
        addFriendYesButton.isEnabled = false
        addFriendNoButton.isEnabled = false
        removeMatchButton.isEnabled = false
        
        FirebaseFunctions.getInstance()
            .getHttpsCallable("removeMatchedCandidate")
            .call(data)
            .addOnSuccessListener {
                Toast.makeText(this, "$otherUserDisplayName is no longer your friend", Toast.LENGTH_LONG).show()
                finish()

            }
            .addOnFailureListener {
                println("unsuccessful $it")
            }
    }
    fun handleRemoveFriendCancel(view:View){
        if(view.id == R.id.remove_friend_cancel_button) {
            finish()
            Toast.makeText(this, "Good choice! :)", Toast.LENGTH_LONG).show()
        }
    }

}