package com.cmpt362.friendrr.profileSetup

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.get
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.R
import java.text.SimpleDateFormat
import java.util.*


class ProfileOneActivity : AppCompatActivity() {

    private lateinit var userName: EditText
    private lateinit var userBirthdate: EditText
    private lateinit var userGenderGroup: RadioGroup
    private lateinit var userFemale: RadioButton
    private lateinit var userMale: RadioButton
    private lateinit var userOther: RadioButton
    private lateinit var userHobbies: ListView
    private lateinit var nextBtn: Button
    private lateinit var selectHobbiesList: ArrayList<String>

    private val calendar = Calendar.getInstance()

    fun selectGenderHelper () {
        if(userFemale.isChecked) {
            ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.GENDER_KEY, "Female")
        } else if(userMale.isChecked) {
            ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.GENDER_KEY, "Male")
        } else if(userOther.isChecked) {
            ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.GENDER_KEY, "Other")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_one)

        userGenderGroup = findViewById(R.id.user_gender)
        selectHobbiesList = ArrayList<String>()
        userFemale = findViewById(R.id.user_female)
        userMale = findViewById(R.id.user_male)
        userOther = findViewById(R.id.user_other)
        userName = findViewById(R.id.user_name)

        // Adapted from: https://stackoverflow.com/a/14933515
        userBirthdate = findViewById(R.id.user_birthdate)
        val datePickerDialog = DatePickerDialog.OnDateSetListener { _, year, monthOfYear, dayOfMonth ->
            calendar.set(Calendar.YEAR, year)
            calendar.set(Calendar.MONTH, monthOfYear)
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateLabel()
        }

        userBirthdate.setOnClickListener {
            DatePickerDialog(this, datePickerDialog, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        userHobbies = findViewById(R.id.hobbies_list)
        userHobbies.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        val arrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(this,
            R.layout.list_item_multiple_choice, Constant.hobbiesList)

        userHobbies.adapter = arrayAdapter
        userHobbies.onItemClickListener = OnItemClickListener { parent, view, position, id ->
            if(selectHobbiesList.contains(Constant.hobbiesList[position])) {
                selectHobbiesList.removeIf{it === Constant.hobbiesList[position]}
            } else{
                selectHobbiesList.add(Constant.hobbiesList[position])
            }
        }


        nextBtn = findViewById(R.id.next_btn)
        nextBtn.setOnClickListener {
            // Verify all fields are filled out
            if (verifyFields()) {
                // Pass information and save it all on the final profile step
                val intent = Intent(this, ProfileTwoActivity::class.java)
                intent.putExtra("username", userName.text.toString())
                ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.DISPLAY_NAME_KEY, userName.text.toString())
                ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.BIRTHDATE_KEY, userBirthdate.text.toString())
                var set = HashSet<String>()
                set.addAll(selectHobbiesList)
                ProfileHelper.addCurrentProfileToLocalStorage(this, Constant.SELECTED_HOBBIES_LIST, set)

                selectGenderHelper()
                startActivity(intent)
            }
        }
    }

    private fun updateLabel() {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.CANADA)
        userBirthdate.setText(dateFormat.format(calendar.time))
    }

    private fun verifyFields(): Boolean {
        // Check username
        if (userName.text.isEmpty()) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_LONG).show()
            return false
        }
        // Check birthdate
        else if (userBirthdate.text.isEmpty()) {
            Toast.makeText(this, "Please enter your birthdate", Toast.LENGTH_LONG).show()
            return false
        }
        // Check gender
        else if (userGenderGroup.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Please select a gender", Toast.LENGTH_LONG).show()
            return false
        }
        // Check hobbies list has at least one option selected
        else if (selectHobbiesList.isEmpty()) {
            Toast.makeText(this, "Please select at least one hobby", Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }
}