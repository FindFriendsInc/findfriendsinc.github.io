package com.cmpt362.friendrr


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.cmpt362.friendrr.chat.ChatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.material.bottomnavigation.BottomNavigationView

import android.view.MenuItem
import android.widget.LinearLayout
import androidx.core.view.isVisible
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.cmpt362.friendrr.addFriend.AddFriendActivity
import com.cmpt362.friendrr.chat.ChatListFragment
import com.cmpt362.friendrr.friendMatch.ReplayViewModel
import com.cmpt362.friendrr.friendMatch.SwipeFragment
import com.cmpt362.friendrr.photoRoulette.IntroPhotoRouletteActivity
import com.cmpt362.friendrr.games.RockPaperScissorActivity
import com.cmpt362.friendrr.leaderboard.LeaderboardFragment
import com.cmpt362.friendrr.profileSetup.EditProfileFragment
import com.google.firebase.messaging.FirebaseMessaging
import com.cmpt362.friendrr.query.AuthQuery
import com.cmpt362.friendrr.viewMatch.ViewMatchFragment
import com.google.android.material.navigation.NavigationBarView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking


class MainActivity : AppCompatActivity() {
    private lateinit var bottomNavView: NavigationBarView
    private var currLoadingState = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var globalViewModel = ViewModelProvider(this).get(GlobalViewModel::class.java)
        globalViewModel.isLoading.observe(this) {
            currLoadingState = it
        }
        bottomNavView = findViewById(R.id.bottomNavigationView)

        // always start with matching fragment first
        val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
        ft.replace(R.id.main_view_id, SwipeFragment())
        ft.commit()

        bottomNavView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.nav_match -> {
                    if(currLoadingState == false){
                        //get the first menu item in the nav bar
                        val menuItem = bottomNavView.menu.getItem(0)
                        //create fragment when the nav item is not checked
                        if(!menuItem.isChecked) {
                            println("I am the match fragment")
                            val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
                            ft.replace(R.id.main_view_id, SwipeFragment())
                            ft.commit()
                        }
                        return@setOnItemSelectedListener true

                    }
                    return@setOnItemSelectedListener false
                }
                R.id.nav_viewmatch -> {
                    if(currLoadingState == false){
                        println("I am the view matches fragment")
                        val menuItem = bottomNavView.menu.getItem(1)
                        if(!menuItem.isChecked) {
                            println("I am the match fragment")
                            val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
                            ft.replace(R.id.main_view_id, ViewMatchFragment())
                            ft.commit()
                        }
                        return@setOnItemSelectedListener true
                    }else{
                        return@setOnItemSelectedListener false
                    }
                }
                R.id.nav_chat -> {
                    if(currLoadingState == false){
                        val menuItem = bottomNavView.menu.getItem(2)
                        //create fragment when the nav item is not checked
                        if(!menuItem.isChecked) {
                            println("I am the chat fragment")
                            val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
                            ft.replace(R.id.main_view_id, ChatListFragment())
                            ft.commit()
                        }
                        return@setOnItemSelectedListener true
                    }
                    return@setOnItemSelectedListener false
                }
                R.id.nav_profile -> {
                    if(currLoadingState == false){
                        //get the first menu item in the nav bar
                        val menuItem = bottomNavView.menu.getItem(3)
                        //create fragment when the nav item is not checked
                        if(!menuItem.isChecked) {
                            println("I am the profile fragment")
                            val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
                            ft.replace(R.id.main_view_id, EditProfileFragment())
                            ft.commit()
                        }
                        return@setOnItemSelectedListener true
                    }
                    else {
                        return@setOnItemSelectedListener false
                    }
                }
                R.id.nav_leaderboard ->{
                    if(currLoadingState == false){
                        val menuItem = bottomNavView.menu.getItem(4)
                        //create fragment when the nav item is not checked
                        if(!menuItem.isChecked) {
                            println("I am the leaderboard fragment")
                            val ft: FragmentTransaction = supportFragmentManager.beginTransaction()
                            ft.replace(R.id.main_view_id, LeaderboardFragment())
                            ft.commit()
                        }
                        return@setOnItemSelectedListener true
                    }
                    return@setOnItemSelectedListener false
                }
                else -> {
                    println("Else")
                    return@setOnItemSelectedListener true
                }
            }
        }

    }
}