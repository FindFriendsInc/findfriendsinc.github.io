package com.cmpt362.friendrr.cardGame

import com.cmpt362.friendrr.cardGame.MemoryCard

class CardDocument(var cards: List<MemoryCard>) {


    constructor(): this(emptyList())

}