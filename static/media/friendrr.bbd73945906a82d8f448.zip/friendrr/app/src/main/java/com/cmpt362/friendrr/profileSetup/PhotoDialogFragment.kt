package com.cmpt362.friendrr.profileSetup

import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.cmpt362.friendrr.Constant
import com.cmpt362.friendrr.MainActivity
import com.cmpt362.friendrr.R

class PhotoDialogFragment(private val activityType: String): DialogFragment() {

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        lateinit var dialog: Dialog
        val view = requireActivity().layoutInflater.inflate(R.layout.fragment_photo_dialog, null)
        val builder = AlertDialog.Builder(requireActivity())
        builder.setView(view)
        builder.setTitle("How do you want to set a profile picture?")
        val photoOptions = arrayOf("Open Camera", "Select from Gallery")
        builder.setItems(photoOptions) { _, option ->
            when(option) {
                0 -> {
                    val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, (activity as ProfileThreeActivity).tempImgUri)

                    try {
                        (activity as ProfileThreeActivity).cameraResult.launch(intent)
                    } catch (e: Exception) {
                        Toast.makeText(
                            activity, "You have not enabled permission to use the camera!", Toast.LENGTH_LONG).show()
                    }
                }
                1 -> {
                    val intent = Intent(Intent.ACTION_PICK)
                    intent.type = "image/*"
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, (activity as ProfileThreeActivity).tempImgUri)

                    try {
                        (activity as ProfileThreeActivity).galleryResult.launch("image/*")
                    } catch (e: Exception) {
                        Toast.makeText(
                            activity, "need permission" +
                                    "to open gallery!", Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
        dialog = builder.create()
        return dialog
    }
}