
const functions = require("firebase-functions");
const auth = require("./AuthFunctions");
const admin = require("firebase-admin");
const { getProfile } = require("./profileFunctions");
const db = admin.firestore();

if (!admin.apps.length) {
    admin.initializeApp();
}

exports.search = functions.https.onCall(async (data, context) => {
    let filtered;
    let matched = [];

    //get current user's email
    let currUserEmail = data.email;

    const currInfo = await db.collection("users").where("email","==",currUserEmail).get();

    let currentUserBirthday;
    let currentUserHobbies;
    let candidateList; //used to filter out on candidates that user has already been matched so there will no be duplicates
    let outgoingRightSwipeList;
    let friendList;

     // retrieve currrent user's birthday and hobbies
    currInfo.forEach(doc =>{
        currentUserBirthday = doc.data().birthDate;
        currentUserHobbies = doc.data().hobbies;
        candidateList = doc.data().matchedCandidateList;
        outgoingRightSwipeList = doc.data().outgoingRightSwipeList;
        friendList = doc.data().friendList;
    })
    let jsonObjects = {}
    const snapshot = await db.collection("users").get();
    snapshot.docs.map( (doc) => {
        let currEmail = doc.data().email
        if(currEmail !== currUserEmail && candidateList.includes(currEmail) !== true &&
        outgoingRightSwipeList.includes(currEmail) !== true && friendList.includes(currEmail) !== true){
            //get user's last login date
            let lastLogin = new Date(doc.data().lastLoggedInDate);
            //convert date into seconds
            let lastLoginSeconds =  Math.round(lastLogin.getTime() / 1000);
            //today's date in seconds
            let todayDateInSeconds = Math.round(Date.now() / 1000);
            // calculate the length which the user last logged in
            let lengthOfLastLogin = todayDateInSeconds - lastLoginSeconds;

            //get current user's birthday and parse it to get the year
            let currUserBirthdayDate = new Date(currentUserBirthday)
            let currUserBirthdayYear = currUserBirthdayDate.getFullYear()

            // get other user's birthday and parse it to get the year
            let userBirthdayDate = new Date(doc.data().birthDate)
            let userBirthdayYear = userBirthdayDate.getFullYear();

            // calcualte the age gap between the current and other user
            let ageGap = currUserBirthdayYear - userBirthdayYear;
        
            // 864000 seconds is 10 days 
            if(lengthOfLastLogin <= 864000 && (ageGap >= -8 && ageGap <= 8 )){
                filtered = doc.data().hobbies.filter(value => currentUserHobbies.includes(value));
                if (filtered.length > 0){
                    let obj={}
                    obj.email = doc.data().email
                    obj.matchedHobbies = filtered.length
                    matched.push(obj);
                }
            }
        }
    })

    let MAX_CAP = 20; //a set restriction to prevent long loading times and large data payload to front-end
    matched.sort((a,b) => b.matchedHobbies - a.matchedHobbies);
    let userObj = []
    for(let i = 0; i < matched.length; i++){
        if(i < MAX_CAP){
            userObj.push(await retrieveUserInfo(matched[i].email));
        }else {
            break;
        }
    }

    return userObj
});

async function retrieveUserInfo(email){
    const snapshot =  await db.collection("users").where("email", "==", email).get();
    let obj = {};
    snapshot.docs.map((doc) => { //exists only one user of a given email in the database, will have only one iteration
        obj.email = doc.data().email;
        obj.displayName = doc.data().displayName;
        obj.birthdate = doc.data().birthdate;
        obj.gender = doc.data().gender;
        obj.hobbies = doc.data().hobbies;
        obj.voiceRecording = doc.data().voiceRecording;
        obj.profilePicture = doc.data().profilePicture;
        obj.isProfileSetup = doc.data().isProfileSetup;
    });
    return obj
}
